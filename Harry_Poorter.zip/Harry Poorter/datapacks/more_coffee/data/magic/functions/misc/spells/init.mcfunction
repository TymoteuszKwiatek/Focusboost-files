# loop init
scoreboard players set .action spells 0

# through floor wand
execute positioned -131 -47 118 summon minecraft:item_display run data merge entity @s {Tags:["spells_entity","spells_rod1"],item:{id:"minecraft:echo_shard",Count:1b},Rotation:[0f,90f],transformation:{scale:[0.7f,0.7f,0.7f]}}
summon interaction -131 -47 118 {Tags:["spells_entity","spells_rod1Interaction"],width:1f,height:1f,repsonse:1b}