# reset
tp @e[tag=Spawn_StartGlow] ~ ~-500 ~
kill @e[tag=Spawn_StartGlow]
kill @e[tag=Spawn_StartText]
kill @e[tag=Spawn_StartInteraction]
kill @e[tag=Spawn_QuitInteraction]
kill @e[tag=Spawn_InfoInteraction]
kill @e[tag=Spawn_QuitText]
kill @e[tag=Spawn_InfoText]
kill @e[tag=Spawn_AuthorsText]
kill @e[tag=Spawn_AuthorsTextt]
# init
summon slime -99 -55 72 {NoAI:1b,Size:1,Silent:1,Tags:["Spawn_StartGlow","Spawn_StartGlowUp"]}
summon minecraft:text_display -98.5 -53.0 72.5 {text:'{"text":"- START -","color":"#FCBA03","bold":"true"}',billboard:"fixed",Tags:["Spawn_StartText"],background:0b,Rotation:[90f,0f]}
summon minecraft:interaction -98.5 -54.75 72.5 {Tags:["Spawn_StartInteraction"],width:1.5,height:1.5,response:1b}

# quit
summon slime -111 -55 60 {NoAI:1b,Size:1,Silent:1,Tags:["Spawn_StartGlow","Spawn_StartGlowUp"]}
summon minecraft:text_display -110.5 -53.0 60.5 {text:'{"text":"- WYJŚCIE -","color":"#FCBA03","bold":"true"}',billboard:"fixed",Tags:["Spawn_QuitText"],background:0b}
summon minecraft:interaction -110.5 -54.75 60.5 {Tags:["Spawn_QuitInteraction"],width:1.5,height:1.5,response:1b}

# informations
summon slime -111 -55 84 {NoAI:1b,Size:1,Silent:1,Tags:["Spawn_StartGlow","Spawn_StartGlowUp"]}
summon minecraft:text_display -110.5 -53.0 84.5 {text:'{"text":"- INFO -","color":"#FCBA03","bold":"true"}',billboard:"fixed",Tags:["Spawn_InfoText"],background:0b,Rotation:[180f,0f]}
summon minecraft:interaction -110.5 -54.75 84.5 {Tags:["Spawn_InfoInteraction"],width:1.5,height:1.5,response:1b}

# authors
summon minecraft:text_display -122.5 -53.0 72.5 {text:'{"text":"- AUTORZY -","color":"#FCBA03","bold":"true"}',billboard:"fixed",Tags:["Spawn_AuthorsText"],background:0b,Rotation:[-90f,0f]}
summon minecraft:text_display -122.5 -53.5 71.5 {text:'{"text":"- Zyvyr -","color":"#51c4f5","bold":"true"}',billboard:"fixed",Tags:["Spawn_AuthorsTextt"],background:0b,Rotation:[-90f,0f]}
summon minecraft:text_display -122.5 -54.0 72.5 {text:'{"text":"- barankowamasakra -","color":"#ffffff","bold":"true"}',billboard:"fixed",Tags:["Spawn_AuthorsTextt"],background:0b,Rotation:[-90f,0f]}
execute positioned -122.5 -54.1 72.5 summon minecraft:text_display run data merge entity @s {text:'{"text":"Tak, to jest jego nick...","color":"#7c868a","bold":"true"}',billboard:"fixed",Tags:["Spawn_AuthorsTextt","Spawn_AuthorsTexttNote"],background:0b,Rotation:[-90f,0f],transformation:{scale:[0.5f,0.5f,0.5f]},text_opacity:4b}
summon minecraft:text_display -122.5 -53.5 73.5 {text:'{"text":"- Kassar -","color":"#32a864","bold":"true"}',billboard:"fixed",Tags:["Spawn_AuthorsTextt"],background:0b,Rotation:[-90f,0f]}

# global
effect give @e[tag=Spawn_StartGlow] minecraft:invisibility infinite 1 true
team join Spawn_StartGlow @e[tag=Spawn_StartGlow]