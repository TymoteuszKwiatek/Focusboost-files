kill @e[tag=levels_entity,tag=!puzzle1]
fill -110 -43 146 -100 -34 156 air destroy
fill -110 -44 146 -100 -44 156 smooth_stone
scoreboard players set .loaded levels 0
setblock -114 -42 151 oak_button[facing=east,powered=false]

clear @a[tag=levels_gameplay]
give @a[tag=levels_gameplay] minecraft:carrot_on_a_stick{CustomModelData:3,Rod:2,display:{Name:'{"text":"PRZEKOMPLIKOWANY-NIESAMOWITY-ZATRZYMYWACZ-UPŁYWU-CZASU","color":"#6a19d4","bold":"true"}'}} 1
give @a[tag=levels_gameplay] minecraft:carrot_on_a_stick{CustomModelData:1,Rod:3,display:{Name:'{"text":"ULTRA-BOSKI-UPADEK-WYSOKIEJ-JAKOŚCI-ZNISZCZENIA","color":"#5bb7f5","bold":"true"}'}} 1
give @a[tag=levels_gameplay] minecraft:carrot_on_a_stick{CustomModelData:2,Rod:1,display:{Name:'{"text":"SUPER-PINGWINI-POŚLIZG","color":"#dfe4e8","bold":"true"}'}} 1