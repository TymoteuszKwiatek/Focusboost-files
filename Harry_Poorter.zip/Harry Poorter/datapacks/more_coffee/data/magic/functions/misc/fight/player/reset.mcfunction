kill @e[tag=armata_model]
kill @e[tag=earth_model]
kill @e[tag=train_model]

setblock -178 -48 85 minecraft:red_carpet
setblock -178 -47 85 minecraft:air

fill -177 -48 86 -177 -48 85 minecraft:air

function magic:misc/fight/items

scoreboard players reset att Fight

scoreboard players add enemy Fight 1