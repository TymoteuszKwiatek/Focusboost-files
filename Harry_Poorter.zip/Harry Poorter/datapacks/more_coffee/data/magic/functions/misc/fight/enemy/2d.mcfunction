scoreboard players add enemytim Fight 1

execute if score enemytim Fight matches 20..80 run particle splash -178.0 -46.0 95.0 0.5 0.5 0.5 0.5 5 force @a

execute if score enemytim Fight matches 20 run tellraw @s [{"text":"<Uczniowie Hudgeward>","color":"red"},{"color":"gray","text":" Bądź świadkiem naszej ogromnej siły!"}]
execute if score enemytim Fight matches 60 run tellraw @s [{"text":"<Uczniowie Hudgeward>","color":"red"},{"color":"gray","text":" LODOWAAAA...."}]
execute if score enemytim Fight matches 80 run tellraw @s [{"text":"<Uczniowie Hudgeward>","color":"red"},{"color":"gray","text":" WŁÓCZNIAAA!!!!"}]

execute if score enemytim Fight matches 80 run playsound minecraft:entity.illusioner.cast_spell master @s ~ ~ ~ 5 1
execute if score enemytim Fight matches 80 run summon minecraft:armor_stand -179 -48 94 {NoGravity:1,Invulnerable:1,Invisible:1,Tags:["ice_spear","fight_model"]}

execute if score enemytim Fight matches 80..87 as @e[tag=ice_spear] at @s run tp @s ~ ~ ~-1
execute if score enemytim Fight matches 80..86 as @e[tag=ice_spear] at @s run setblock ~ ~1 ~ minecraft:packed_ice
execute if score enemytim Fight matches 80..87 as @e[tag=ice_spear] at @s run fill ~ ~1 ~1 ~ ~1 ~1 minecraft:air destroy

execute if score enemytim Fight matches 87 run playsound minecraft:meme12 master @s ~ ~ ~ 5 1
execute if score enemytim Fight matches 87 run particle minecraft:poof -179 -46 86 0 0 0 0.05 15 force @a
execute if score enemytim Fight matches 87 run kill @e[tag=ice_spear]

execute if score enemytim Fight matches 130 run data merge entity @e[tag=earth_model,limit=1] {transformation:{translation:[0.0f,0.0f,9.0f]},start_interpolation:-1,interpolation_duration:10}

execute if score enemytim Fight matches 140 run particle minecraft:block redstone_block -178.0 -46.0 95.0 0.5 0.5 0.5 0.5 50 force @a
execute if score enemytim Fight matches 140 run particle minecraft:explosion_emitter -178.0 -46.0 95.0 0.5 0.5 0.5 0.5 10 force @a
execute if score enemytim Fight matches 140 run playsound minecraft:entity.generic.explode master @s ~ ~ ~ 5 0
execute if score enemytim Fight matches 140 run playsound minecraft:entity.generic.explode master @s ~ ~ ~ 5 1

execute if score enemytim Fight matches 160.. run function magic:misc/fight/player/reset
execute if score enemytim Fight matches 160.. run tag @s remove enemy_turn
execute if score enemytim Fight matches 160.. run tag @s add deal_dmg
execute if score enemytim Fight matches 160.. run scoreboard players reset enemytim Fight