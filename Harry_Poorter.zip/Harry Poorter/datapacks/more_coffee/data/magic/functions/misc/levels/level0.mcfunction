# init
scoreboard players set .boxEnd levels 1
kill @e[tag=levels_entity,tag=!puzzle1]
summon minecraft:armor_stand -104 -43 151 {Tags:["Puzzle_Box","levels_entity"],Invulnerable:1b,DisabledSlots:4144959,Marker:0b,Invisible:1b,ArmorItems:[{},{},{},{id:"minecraft:cake",Count:1b}]}

# blocks
setblock -105 -43 150 minecraft:tuff
setblock -105 -44 151 minecraft:stripped_mangrove_log[axis=y]
setblock -106 -43 156 minecraft:tuff

# reset
scoreboard players set .loaded levels 1