tag @s remove Puzzle_BoxStopRay
particle minecraft:crit ~ ~ ~ 0 0 0 0 1 force @a
execute align xzy positioned ~0.5 ~ ~0.5 if entity @e[tag=Puzzle_Box,distance=..0.1] if block ~ ~-1 ~ minecraft:brown_glazed_terracotta run particle minecraft:splash ~ ~ ~ 0.2 0.2 0.2 1 100 force @a
execute align xzy positioned ~0.5 ~ ~0.5 if entity @e[tag=Puzzle_Box,distance=..0.1] if block ~ ~-1 ~ minecraft:brown_glazed_terracotta run playsound minecraft:entity.generic.splash master @s ~ ~ ~ 1 1
execute align xzy positioned ~0.5 ~ ~0.5 if entity @e[tag=Puzzle_Box,distance=..0.1] if block ~ ~-1 ~ minecraft:brown_glazed_terracotta run tag @s add Puzzle_BoxStopRay
execute align xzy positioned ~0.5 ~ ~0.5 as @e[tag=Puzzle_Box,distance=..0.1] if block ~ ~-1 ~ minecraft:brown_glazed_terracotta run tp @s ~ ~-2 ~

execute as @s[distance=..6] positioned ^ ^ ^0.5 if block ~ ~ ~ air unless entity @s[tag=Puzzle_BoxStopRay] run function magic:misc/spells/tp_spell
tag @s remove Puzzle_BoxStopRay