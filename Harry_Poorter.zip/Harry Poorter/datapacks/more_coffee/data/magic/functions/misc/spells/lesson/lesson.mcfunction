# rod 1 take
# use
execute as @e[tag=spells_rod1Interaction] if data entity @s interaction on target run playsound minecraft:block.note_block.guitar master @s ~ ~ ~ 10 1
execute as @e[tag=spells_rod1Interaction] if data entity @s interaction on target run give @s minecraft:carrot_on_a_stick{Rod:3,display:{Name:'{"text":"ULTRA-BOSKI-UPADEK-WYSOKIEJ-JAKOŚCI-ZNISZCZENIA","color":"#3978bf","bold":"true"}'}} 1
execute as @e[tag=spells_rod1Interaction] if data entity @s interaction run kill @e[tag=spells_rod1]
execute as @e[tag=spells_rod1Interaction] if data entity @s interaction run scoreboard players set .action spells 1
execute as @e[tag=spells_rod1Interaction] if data entity @s interaction run kill @s
# hit
execute as @e[tag=spells_rod1Interaction] if data entity @s attack on attacker run playsound minecraft:block.note_block.guitar master @s ~ ~ ~ 10 1
execute as @e[tag=spells_rod1Interaction] if data entity @s attack on attacker run give @s minecraft:carrot_on_a_stick{Rod:3,display:{Name:'{"text":"ULTRA-BOSKI-UPADEK-WYSOKIEJ-JAKOŚCI-ZNISZCZENIA","color":"#3978bf","bold":"true"}'}} 1
execute as @e[tag=spells_rod1Interaction] if data entity @s attack run kill @e[tag=spells_rod1]
execute as @e[tag=spells_rod1Interaction] if data entity @s attack run scoreboard players set .action spells 1
execute as @e[tag=spells_rod1Interaction] if data entity @s attack run kill @s

# loop
execute if score .action spells matches 1 run scoreboard players add .time spells 1

# >
execute if score .time spells matches 1 run summon armor_stand -132 -46 115 {NoGravity:1,Invisible:1,Invulnerable:1,DisabledSlots:4144959,Tags:["spells_cam_gameplay","spells_entity"],Rotation:[-114f,17f],Silent:1}
execute if score .time spells matches 20 run title @s times 5 10 5
execute if score .time spells matches 20 run title @s title {"text":"\uE000"}
execute if score .time spells matches 25..2169 run gamemode spectator @s
execute if score .time spells matches 25..2169 run spectate @e[tag=spells_cam_gameplay,limit=1] @s
execute if score .time spells matches 25 run item replace entity @s armor.head with minecraft:carved_pumpkin{Enchantments:[{id:"minecraft:binding_curse",lvl:1s}]}

execute if score .time spells matches 40 run tellraw @s [{"text":"<Bogden Niewysoki>","color":"gold"},{"color":"gray","bold":"false","text":" Świetnie! Znalazłeś pierwszom ruszczkem, teras pokasze ci jak jom óżyć!"}]
execute if score .time spells matches 40 run playsound minecraft:talk1 master @s -128 -47 118 1 0.8

execute if score .time spells matches 140 run tellraw @s [{"text":"<Bogden Niewysoki>","color":"gold"},{"color":"gray","bold":"false","text":" Ale zanim to nastąpi, potrzebujemy celu do ćwiczeń... "}]
execute if score .time spells matches 140 run playsound minecraft:talk1 master @s -128 -47 118 1 0.8

execute if score .time spells matches 250 run setblock -126 -46 110 minecraft:brown_glazed_terracotta
execute if score .time spells matches 250 run setblock -126 -46 115 minecraft:oak_planks
execute if score .time spells matches 250 run summon minecraft:armor_stand -126 -44 110 {Tags:["Puzzle_Box","spells_entity","spells_box1"],Invulnerable:1b,DisabledSlots:4144959,Marker:0b,Invisible:1b,ArmorItems:[{},{},{},{id:"minecraft:cake",Count:1b}]}
execute if score .time spells matches 250 run summon minecraft:armor_stand -126 -44 115 {Tags:["Puzzle_Box","spells_entity","spells_box2"],Invulnerable:1b,DisabledSlots:4144959,Marker:0b,Invisible:1b,ArmorItems:[{},{},{},{id:"minecraft:cake",Count:1b}]}

execute if score .time spells matches 250 run tellraw @s [{"text":"<Bogden Niewysoki>","color":"gold"},{"color":"gray","bold":"false","text":" Wyczaruje teraz lek na mądrość..."}]
execute if score .time spells matches 250 run playsound minecraft:talk1 master @s ~ ~ ~ 1 0.8
execute if score .time spells matches 350 run tellraw @s [{"text":"<Bogden Niewysoki>","color":"gold"},{"color":"gray","bold":"false","text":" Oh, nie udało się, ale spójrz na te identyczne skrzynki różniące się od siebie jedną rzeczą... wiesz jaką?"}]
execute if score .time spells matches 350 run playsound minecraft:talk2 master @s ~ ~ ~ 1 0.8
execute if score .time spells matches 450 run tellraw @s [{"text":"<Bogden Niewysoki>","color":"gold"},{"color":"gray","bold":"false","text":" P O D Ł O G Ą!, aby użyć tego niesamowitego zaklęcia, skrzynki muszą być na brązowej glazurowanej terakocie."}]
execute if score .time spells matches 450 run playsound minecraft:talk3 master @s ~ ~ ~ 1 0.8
execute if score .time spells matches 550 run tellraw @s [{"text":"<Bogden Niewysoki>","color":"gold"},{"color":"gray","bold":"false","text":" Przetestujmy to, rzucam teraz (...) zaklęcie na te dwie skrzynie."}]
execute if score .time spells matches 550 run playsound minecraft:talk1 master @s ~ ~ ~ 0.8
execute if score .time spells matches 650 run tellraw @s [{"text":"<Bogden Niewysoki>","color":"gold"},{"color":"gray","bold":"false","text":" Widzicie! Zgodnie z planem!"}]
execute if score .time spells matches 650 run playsound minecraft:talk2 master @s ~ ~ ~ 1 0.8
execute if score .time spells matches 650 run tag @e[tag=spells_box1] add spells_box1Tp

# box tp through floor
execute if score .time spells matches 650 as @e[tag=spells_box1Tp] at @s run particle minecraft:splash ~ ~ ~ 0.2 0.2 0.2 1 100 force @a
execute if score .time spells matches 650 as @e[tag=spells_box1Tp] at @s run tp @s ~ ~-2 ~
execute if score .time spells matches 650 run playsound minecraft:entity.generic.splash master @s ~ ~ ~ 1 1

execute if score .time spells matches 750 run tellraw @s [{"text":"<Bogden Niewysoki>","color":"gold"},{"color":"gray","bold":"false","text":" To jest zbyt nudne, by czekać aż sami odnajdziecie wszystkie ruszczki, więc zrobiłem to za was ;o uwu"}]
execute if score .time spells matches 750 run playsound minecraft:talk3 master @s ~ ~ ~ 1 0.8
execute if score .time spells matches 850 run tellraw @s [{"text":"<Bogden Niewysoki>","color":"gold"},{"color":"gray","bold":"false","text":" Następne zaklęcie to SUPER-PINGWINI-POŚLIZG"}]
execute if score .time spells matches 850 run playsound minecraft:talk1 master @s ~ ~ ~ 1 0.8

# push spell
execute if score .time spells matches 900 run setblock -126 -46 110 air destroy
execute if score .time spells matches 900 run setblock -126 -46 115 air destroy
execute if score .time spells matches 910 run setblock -124 -48 115 mangrove_planks
execute if score .time spells matches 910 as @e[tag=spells_box1] at @s run tp @s -127 -48 114 180 0
execute if score .time spells matches 910 as @e[tag=spells_box2] at @s run tp @s -127 -48 110 -90 0

execute if score .time spells matches 950 run tellraw @s [{"text":"<Bogden Niewysoki>","color":"gold"},{"color":"gray","bold":"false","text":" To zaklęcie jest w stanie POPCHNĄĆ skrzynkę aż do zetknięcia się ze ścianą lub inną skrzynką."}]
execute if score .time spells matches 950 run playsound minecraft:talk2 master @s ~ ~ ~ 1 0.8

execute if score .time spells matches 1050 run tellraw @s [{"text":"<Bogden Niewysoki>","color":"gold"},{"color":"gray","bold":"false","text":" Proszę spojrzyć na ten przykład;"}]
execute if score .time spells matches 1050 run playsound minecraft:talk3 master @s ~ ~ ~ 1 0.8
# example
execute if score .time spells matches 1150 as @e[tag=spells_box1] run tag @s add Puzzle_BoxPush
execute if score .time spells matches 1200 as @e[tag=spells_box2] run tag @s add Puzzle_BoxPush
execute if score .time spells matches 1249 as @e[tag=spells_box2] at @s run tp @s ~ ~ ~ 0 0
execute if score .time spells matches 1250 as @e[tag=spells_box2] run tag @s add Puzzle_BoxPush

execute if score .time spells matches 1270 run tellraw @s [{"text":"<Bogden Niewysoki>","color":"gold"},{"color":"gray","bold":"false","text":" To moje ulubione zaklęcie, mogę go używać cały czas!"}]
execute if score .time spells matches 1270 run playsound minecraft:talk1 master @s ~ ~ ~ 1 0.8

execute if score .time spells matches 1370 run tellraw @s [{"text":"<Bogden Niewysoki>","color":"gold"},{"color":"gray","bold":"false","text":" A ostatnie zaklęcie, którego was nauczę, to PRZEKOMPLIKOWANY-NIESAMOWITY-ZATRZYMYWACZ-UPŁYWU-CZASU"}]
execute if score .time spells matches 1370 run playsound minecraft:talk2 master @s ~ ~ ~ 1 0.8

execute if score .time spells matches 1470 run tellraw @s [{"text":"<Bogden Niewysoki>","color":"gold"},{"color":"gray","bold":"false","text":" Wydaje mi się, że nazwa mówi sama za siebie, ale dla pewności, spójrzcie na ten przykład;"}]
execute if score .time spells matches 1470 run playsound minecraft:talk3 master @s ~ ~ ~ 1 0.8

# example
execute if score .time spells matches 1570 run setblock -126 -46 110 minecraft:oak_planks
execute if score .time spells matches 1570 run setblock -126 -46 115 minecraft:oak_planks
execute if score .time spells matches 1570 as @e[tag=spells_box1] run tp @s -126 -44 110 0 0
execute if score .time spells matches 1570 as @e[tag=spells_box2] run tp @s -126 -44 115 0 0
execute if score .time spells matches 1570 run setblock -124 -48 115 air destroy
execute if score .time spells matches 1580 as @e[tag=spells_box1] run tag @s add Puzzle_BoxLock
execute if score .time spells matches 1630 run setblock -126 -46 110 air destroy

execute if score .time spells matches 1650 run tellraw @s [{"text":"<Bogden Niewysoki>","color":"gold"},{"color":"gray","bold":"false","text":" Zatrzymywacz czasu, cóż za wspaniały wynalazek!!"}]
execute if score .time spells matches 1650 run playsound minecraft:talk1 master @s ~ ~ ~ 1 0.8

# rocket teacher
execute if score .time spells matches 1750 run tellraw @s [{"text":"<Bogden Niewysoki>","color":"gold"},{"color":"gray","bold":"false","text":" Dobra, to wszystko na dzi..."}]
execute if score .time spells matches 1750 run playsound minecraft:talk1 master @s ~ ~ ~ 1 0.8
execute if score .time spells matches 1750 run playsound minecraft:meme4 master @s -141.45 -47.00 110.18 1 1

execute if score .time spells matches 1850 run tellraw @s [{"text":"<Bogden Niewysoki>","color":"gold"},{"color":"gray","bold":"false","text":" KTO ŚMIE MI PONOWNIE PRZERYWAĆ!!!"}]
execute if score .time spells matches 1850 run playsound minecraft:talk1 master @s ~ ~ ~ 1 0.8

execute if score .time spells matches 1950 run tellraw @s [{"text":"<Bogden Niewysoki>","color":"gold"},{"color":"gray","bold":"false","text":" NIE POZWOLĘ TYM RAZEM!!"}]
execute if score .time spells matches 1950 run playsound minecraft:talk1 master @s ~ ~ ~ 1 0.8

execute if score .time spells matches 2050 run tellraw @s [{"text":"<Bogden Niewysoki>","color":"gold"},{"color":"gray","bold":"false","text":" NADCIĄGAM!!"}]
execute if score .time spells matches 2050 run playsound minecraft:talk1 master @s ~ ~ ~ 1 0.8
# rocket
execute if score .time spells matches 2100..2118 as @e[tag=spells_teacher] at @s run tp @s ~ ~ ~ ~ ~-5
execute if score .time spells matches 2100..2123 as @e[tag=spells_teacher] at @s run tp @s ~ ~ ~ ~60 ~
execute if score .time spells matches 2125..2170 as @e[tag=spells_teacher] at @s run tp @s ~-0.5 ~ ~-0.05

# end cutscene
execute if score .time spells matches 2171 run title @s times 5 10 5
execute if score .time spells matches 2171 run title @s title {"text":"\uE000"}

execute if score .time spells matches 2171 run fill -161 -46 111 -161 -48 110 air
execute if score .time spells matches 2171 run fill -136 -46 111 -136 -48 110 air
execute if score .time spells matches 2171 run playsound minecraft:door master @a ~ ~ ~ 1 1

execute if score .time spells matches 2176.. run item replace entity @s armor.head with air
execute if score .time spells matches 2176.. run clear @s
execute if score .time spells matches 2176.. run gamemode adventure @s
execute if score .time spells matches 2176.. run tp @s -131 -47 117 -122 1
execute if score .time spells matches 2176.. run setblock -126 -46 115 air destroy
execute if score .time spells matches 2176.. run kill @e[tag=spells_entity]
execute if score .time spells matches 2176.. run scoreboard players set .action spells 0
execute if score .time spells matches 2176.. run tag @s remove spells_gameplay
execute if score .time spells matches 2176.. run scoreboard players reset .time spells


