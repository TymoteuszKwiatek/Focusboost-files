
# another box collisions
execute as @e[tag=Puzzle_BoxPush] at @s positioned ^ ^ ^1 align xz positioned ~0.5 ~ ~0.5 if entity @e[tag=Puzzle_Box,distance=..0.5,sort=nearest,limit=1] positioned ^ ^ ^-1 align xzy positioned ~0.5 ~ ~0.5 run function magic:misc/spells/push_fix


#down
#execute as @e[tag=Puzzle_Box,tag=!Puzzle_BoxPush] at @s positioned ~ ~-1 ~ if entity @e[tag=Puzzle_Box,distance=..0.2] run say test
execute as @e[tag=Puzzle_Box,tag=!Puzzle_BoxPush] at @s positioned ~ ~-1 ~ if entity @e[tag=Puzzle_Box,distance=..0.2] run data merge entity @s {NoGravity:1b}
execute as @e[tag=Puzzle_Box,tag=!Puzzle_BoxPush,tag=!Puzzle_BoxFixed] at @s positioned ~ ~-1 ~ if entity @e[tag=Puzzle_Box,distance=..0.2] run tp @s ~ ~1.15 ~
execute as @e[tag=Puzzle_Box,tag=!Puzzle_BoxPush,tag=!Puzzle_BoxFixed] at @s positioned ~ ~-1 ~ if entity @e[tag=Puzzle_Box,distance=..0.2] run tag @s add Puzzle_BoxFixed
execute as @e[tag=Puzzle_BoxFixed] at @s unless block ~ ~-0.1 ~ air run tag @s remove Puzzle_BoxFixed

# push spell
execute as @e[tag=Puzzle_BoxPush] at @s if block ^ ^ ^1 air run tp @s ^ ^ ^1
execute as @e[tag=Puzzle_BoxPush] at @s unless block ^ ^ ^1 air align xz positioned ~0.5 ~ ~0.5 run function magic:misc/spells/push_fix

# puzzle box
execute as @e[tag=Puzzle_Box,tag=!Puzzle_BoxPush] unless score @s Lock_Spell matches 40.. at @s if block ~ ~-0.1 ~ air positioned ~ ~-1 ~ unless entity @e[tag=Puzzle_Box,distance=..0.2] run data merge entity @s {NoGravity:0b}
execute as @e[tag=Puzzle_Box,tag=!Puzzle_BoxPush] unless score @s Lock_Spell matches 40.. at @s unless block ~ ~-0.1 ~ air positioned ~ ~-1 ~ if entity @e[tag=Puzzle_Box,distance=..0.2] run data merge entity @s {NoGravity:1b}

execute as @e[tag=Puzzle_Box,tag=!Puzzle_BoxPush,tag=!Puzzle_BoxLock] at @s unless block ~ ~-0.1 ~ air run data merge entity @s {Marker:1b}
execute as @e[tag=Puzzle_Box,tag=!Puzzle_BoxPush,tag=!Puzzle_BoxLock] at @s if block ~ ~-0.1 ~ air positioned ~ ~-1 ~ unless entity @e[tag=Puzzle_Box,distance=..0.2] run data merge entity @s {Marker:0b}
execute as @e[tag=Puzzle_Box,tag=!Puzzle_BoxPush,tag=!Puzzle_BoxLock] at @s if block ~ ~-0.1 ~ air positioned ~ ~-1 ~ if entity @e[tag=Puzzle_Box,distance=..0.2] run data merge entity @s {Marker:1b}

# lock spell
scoreboard players add @e[tag=Puzzle_BoxLock] Lock_Spell 1
execute as @e[tag=Puzzle_BoxLock] at @s if score @s Lock_Spell matches 1..10 run particle minecraft:dust 0 1 0 1 ~ ~1.3 ~ 0.1 0.1 0.1 1 5 force @a
execute as @e[tag=Puzzle_BoxLock] at @s if score @s Lock_Spell matches 10..20 run particle minecraft:dust 1 1 0 1 ~ ~1.3 ~ 0.1 0.1 0.1 0 5 force @a
execute as @e[tag=Puzzle_BoxLock] at @s if score @s Lock_Spell matches 20..30 run particle minecraft:dust 1 0.5 0 1 ~ ~1.3 ~ 0.1 0.1 0.1 0 5 force @a
execute as @e[tag=Puzzle_BoxLock] at @s if score @s Lock_Spell matches 30..40 run particle minecraft:dust 1 0 0 1 ~ ~1.3 ~ 0.1 0.1 0.1 0 5 force @a
execute as @e[tag=Puzzle_BoxLock] at @s if score @s Lock_Spell matches 40.. run particle minecraft:dust 0.2 0.1 0.3 1 ~ ~1.3 ~ 0.1 0.1 0.1 0 5 force @a
execute as @e[tag=Puzzle_BoxLock] at @s if score @s Lock_Spell matches 40 run data merge entity @s {NoGravity:1b}
execute as @e[tag=Puzzle_BoxLock] at @s if score @s Lock_Spell matches 90 run function magic:misc/spells/unlock
