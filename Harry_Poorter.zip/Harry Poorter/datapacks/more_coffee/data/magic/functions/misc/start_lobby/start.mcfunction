execute on target run tag @s add intro
execute on attacker run tag @s add intro