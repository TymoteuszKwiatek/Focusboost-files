execute if score .loaded levels matches 0 if score .level levels matches 0 run function magic:misc/levels/level0
execute if score .loaded levels matches 0 if score .level levels matches 1 run function magic:misc/levels/level1
execute if score .loaded levels matches 0 if score .level levels matches 2 run function magic:misc/levels/level2
execute if score .loaded levels matches 0 if score .level levels matches 3 run function magic:misc/levels/level3
execute if score .loaded levels matches 0 if score .level levels matches 4 run function magic:misc/levels/level4
execute if score .loaded levels matches 0 if score .level levels matches 5 run function magic:misc/levels/level5
execute if score .loaded levels matches 0 if score .level levels matches 6 run function magic:misc/levels/level6
execute if score .loaded levels matches 0 if score .level levels matches 7 run function magic:misc/levels/level7
execute if score .loaded levels matches 0 if score .level levels matches 8 run function magic:misc/levels/level8
execute if score .loaded levels matches 0 if score .level levels matches 9 run function magic:misc/levels/level9
execute if score .loaded levels matches 0 if score .level levels matches 10 run function magic:misc/levels/level10

# tags / level end
execute store result score .boxNow levels run execute if entity @e[tag=Puzzle_Box,tag=!Puzzle_BoxPush,tag=Puzzle_BoxEnding]
execute as @e[tag=Puzzle_Box,tag=!Puzzle_BoxPush,tag=!Puzzle_BoxEnding] at @s if block ~ ~-0.7 ~ stripped_mangrove_log run tag @s add Puzzle_BoxEnding
execute as @e[tag=Puzzle_Box,tag=!Puzzle_BoxPush,tag=Puzzle_BoxEnding] at @s unless block ~ ~-0.7 ~ stripped_mangrove_log unless block ~0.7 ~ ~ stripped_mangrove_log unless block ~-0.7 ~ ~ stripped_mangrove_log unless block ~ ~ ~0.7 stripped_mangrove_log unless block ~ ~ ~-0.7 stripped_mangrove_log run tag @s remove Puzzle_BoxEnding

execute as @e[tag=Puzzle_Box,tag=!Puzzle_BoxPush,tag=!Puzzle_BoxEnding] at @s if block ~0.7 ~ ~ stripped_mangrove_log run tag @s add Puzzle_BoxEnding
execute as @e[tag=Puzzle_Box,tag=!Puzzle_BoxPush,tag=!Puzzle_BoxEnding] at @s if block ~-0.7 ~ ~ stripped_mangrove_log run tag @s add Puzzle_BoxEnding
execute as @e[tag=Puzzle_Box,tag=!Puzzle_BoxPush,tag=!Puzzle_BoxEnding] at @s if block ~ ~ ~0.7 stripped_mangrove_log run tag @s add Puzzle_BoxEnding
execute as @e[tag=Puzzle_Box,tag=!Puzzle_BoxPush,tag=!Puzzle_BoxEnding] at @s if block ~ ~ ~-0.7 stripped_mangrove_log run tag @s add Puzzle_BoxEnding
execute as @e[tag=Puzzle_Box,tag=!Puzzle_BoxPush,tag=Puzzle_BoxEnding] at @s unless block ~ ~-0.7 ~ stripped_mangrove_log unless block ~0.7 ~ ~ stripped_mangrove_log unless block ~-0.7 ~ ~ stripped_mangrove_log unless block ~ ~ ~0.7 stripped_mangrove_log unless block ~ ~ ~-0.7 stripped_mangrove_log run tag @s remove Puzzle_BoxEnding

# level complete
execute if score .boxNow levels = .boxEnd levels run scoreboard players add .delay levels 1
execute as @e[tag=Puzzle_BoxEnding] at @s run particle minecraft:firework ~ ~0.5 ~ 0.3 0.3 0.3 0.1 3 force @a
execute if score .delay levels matches 20 as @a at @s run playsound minecraft:ui.toast.challenge_complete master @a ~ ~ ~ 1 2
execute if score .delay levels matches 20 run scoreboard players add .level levels 1
execute if score .delay levels matches 20 if score .level levels matches 11 run function magic:misc/levels/to_ending
execute if score .delay levels matches 20 as @a at @s unless score .level levels matches 11 run title @a title [{"text":"Level ","color":"gold","bold":"true"},{"score":{"name":".level","objective":"levels"}}]
execute if score .delay levels matches 20 run function magic:misc/levels/reset
execute if score .delay levels matches 20 run scoreboard players set .delay levels 0

# level skip
execute if block -114 -42 147 oak_button[powered=true] as @a at @s run playsound minecraft:entity.illusioner.cast_spell master @s ~ ~ ~ 1 0
execute if block -114 -42 147 oak_button[powered=true] run scoreboard players add .level levels 1
execute if block -114 -42 147 oak_button[powered=true] if score .level levels matches 11 run function magic:misc/levels/to_ending
execute if block -114 -42 147 oak_button[powered=true] unless score .level levels matches 11 run function magic:misc/levels/reset
execute if block -114 -42 147 oak_button[powered=true] unless score .level levels matches 11 run title @a title [{"text":"Level ","color":"gold","bold":"true"},{"score":{"name":".level","objective":"levels"}}]
execute if block -114 -42 147 oak_button[powered=true] run setblock -114 -42 147 oak_button[powered=false,facing=east]

# level music
scoreboard players add .loop levels 1
execute if score .loop levels matches 1 run playsound minecraft:puzzle master @a[tag=levels_gameplay] ~ ~ ~ 1000 0
execute if score .loop levels matches 5760 run scoreboard players set .loop levels 0

# reset
execute if block -114 -42 151 oak_button[powered=true] as @a at @s run playsound minecraft:entity.illusioner.prepare_blindness master @s ~ ~ ~ 1 1
execute if block -114 -42 151 oak_button[powered=true] run function magic:misc/levels/reset