tag @s remove potions_arrows
kill @e[tag=potions_CauldronText]