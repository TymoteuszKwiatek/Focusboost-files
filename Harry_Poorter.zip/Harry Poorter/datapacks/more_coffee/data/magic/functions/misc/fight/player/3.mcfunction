scoreboard players add player Fight 1

execute if score player Fight matches 20 run playsound minecraft:item.armor.equip_generic master @s ~ ~ ~ 5 1
execute if score player Fight matches 20 run summon minecraft:item_display -178.0 -45.5 85.0 {item:{id:"minecraft:player_head",Count:1b,tag:{SkullOwner: {Id: [I; -227925152, 22564726, -1976241017, -2009126140], Properties: {textures: [{Value: "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvYzljODg4MWU0MjkxNWE5ZDI5YmI2MWExNmZiMjZkMDU5OTEzMjA0ZDI2NWRmNWI0MzliM2Q3OTJhY2Q1NiJ9fX0="}]}}}},Tags:["earth_model","fight_model"]}

execute if score player Fight matches 80 run playsound minecraft:entity.item.pickup master @s ~ ~ ~ 5 0
execute if score player Fight matches 80 run data merge entity @e[tag=earth_model,limit=1] {transformation:{scale:[4.0f,4.0f,4.0f]}}

execute if score player Fight matches 100.. run tag @s add enemy_turn
execute if score player Fight matches 100.. run scoreboard players reset player Fight