scoreboard players add enemytim Fight 1

execute if score enemytim Fight matches 20..80 run particle crit -178.0 -46.0 95.0 0.5 0.5 0.5 0.5 5 force @a

execute if score enemytim Fight matches 20 run tellraw @s [{"text":"<Uczniowie Hudgeward>","color":"red"},{"color":"gray","text":" Doświadcz naszej mocy!"}]
execute if score enemytim Fight matches 60 run tellraw @s [{"text":"<Uczniowie Hudgeward>","color":"red"},{"color":"gray","text":" BŁYSKAAA...."}]
execute if score enemytim Fight matches 80 run tellraw @s [{"text":"<Uczniowie Hudgeward>","color":"red"},{"color":"gray","text":" WICAAAA!!!!"}]

execute if score enemytim Fight matches 80 run particle minecraft:firework -178.04 -46.89 83.65 0.2 0.2 0.2 0.1 50 force @a
execute if score enemytim Fight matches 80 run particle minecraft:flash -178.04 -46.89 83.65 0.1 0.1 0.1 0.1 3 force @a
execute if score enemytim Fight matches 80 run playsound minecraft:item.trident.thunder master @s ~ ~ ~ 5 1

execute if score enemytim Fight matches 140..170 run summon minecraft:lightning_bolt -178.04 -46.89 83.65
execute if score enemytim Fight matches 140..170 run particle minecraft:explosion -178.04 -46.89 83.65 0.5 0.5 0.5 0.1 1 force @a

execute if score enemytim Fight matches 190.. run function magic:misc/fight/player/reset
execute if score enemytim Fight matches 190.. run tag @s remove enemy_turn
execute if score enemytim Fight matches 190.. run tag @s add hurt
execute if score enemytim Fight matches 190.. run scoreboard players reset enemytim Fight