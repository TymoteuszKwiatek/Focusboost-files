scoreboard players add enemytim Fight 1

execute if score enemytim Fight matches 20..80 run particle crit -178.0 -46.0 95.0 0.5 0.5 0.5 0.5 5 force @a

execute if score enemytim Fight matches 20 run tellraw @s [{"text":"<Uczniowie Hudgeward>","color":"red"},{"color":"gray","text":" Doświadcz naszej mocy!"}]
execute if score enemytim Fight matches 60 run tellraw @s [{"text":"<Uczniowie Hudgeward>","color":"red"},{"color":"gray","text":" BŁYSKAAA...."}]
execute if score enemytim Fight matches 80 run tellraw @s [{"text":"<Uczniowie Hudgeward>","color":"red"},{"color":"gray","text":" WICAAAAAA!!!!"}]

execute if score enemytim Fight matches 80 run particle minecraft:firework -178.04 -46.89 83.65 0.2 0.2 0.2 0.1 50 force @a
execute if score enemytim Fight matches 80 run particle minecraft:flash -178.04 -46.89 83.65 0.1 0.1 0.1 0.1 3 force @a
execute if score enemytim Fight matches 80 run playsound minecraft:item.trident.thunder master @s ~ ~ ~ 5 1

execute if score enemytim Fight matches 100 run data merge entity @e[tag=fight_player2,limit=1] {transformation:{translation:[-1.5f,0.0f,-3.0f],left_rotation:{axis:[1.0f,0.0f,0.0f],angle:1.57}},start_interpolation:-1,interpolation_duration:10}

execute if score enemytim Fight matches 140..170 run summon minecraft:lightning_bolt -178.04 -46.89 83.65
execute if score enemytim Fight matches 140..170 run particle minecraft:explosion -178.04 -46.89 83.65 0.5 0.5 0.5 0.1 1 force @a

execute if score enemytim Fight matches 190 run data merge entity @e[tag=fight_player2,limit=1] {transformation:{translation:[0.0f,0.0f,0.0f],left_rotation:{axis:[1.0f,0.0f,0.0f],angle:0.0}},start_interpolation:-1,interpolation_duration:10}

execute if score enemytim Fight matches 210 run particle minecraft:block redstone_block -178.0 -46.0 95.0 0.5 0.5 0.5 0.5 50 force @a
execute if score enemytim Fight matches 210 run playsound minecraft:entity.player.hurt master @s ~ ~ ~ 5 1

execute if score enemytim Fight matches 230.. run function magic:misc/fight/player/reset
execute if score enemytim Fight matches 230.. run tag @s remove enemy_turn
execute if score enemytim Fight matches 230.. run tag @s add deal_dmg
execute if score enemytim Fight matches 230.. run scoreboard players reset enemytim Fight