# init
scoreboard players set .boxEnd levels 2
kill @e[tag=levels_entity,tag=!puzzle1]
summon minecraft:armor_stand -108 -40 151 {Tags:["Puzzle_Box","levels_entity"],Invulnerable:1b,DisabledSlots:4144959,Marker:0b,Invisible:1b,ArmorItems:[{},{},{},{id:"minecraft:cake",Count:1b}]}

summon minecraft:armor_stand -102 -35 151 {Tags:["Puzzle_Box","levels_entity"],Invulnerable:1b,DisabledSlots:4144959,Marker:0b,Invisible:1b,ArmorItems:[{},{},{},{id:"minecraft:cake",Count:1b}]}

# blocks
setblock -108 -41 151 minecraft:smooth_stone
setblock -102 -36 151 minecraft:smooth_stone
setblock -106 -35 151 minecraft:smooth_stone
setblock -105 -36 151 minecraft:brown_glazed_terracotta[facing=north]
setblock -106 -39 151 minecraft:smooth_stone
setblock -104 -40 151 minecraft:smooth_stone
setblock -101 -40 151 minecraft:smooth_stone
fill -105 -43 154 -105 -42 154 smooth_stone
fill -106 -43 155 -104 -43 156 smooth_stone

# ends
setblock -105 -43 156 minecraft:stripped_mangrove_log[axis=y]
setblock -105 -44 151 minecraft:stripped_mangrove_log[axis=y]

# reset
scoreboard players set .loaded levels 1