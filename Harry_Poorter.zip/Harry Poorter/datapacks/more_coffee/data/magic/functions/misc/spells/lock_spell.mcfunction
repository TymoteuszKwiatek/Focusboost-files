tag @s remove Puzzle_BoxStopRay
particle minecraft:crit ~ ~ ~ 0 0 0 0 1 force @a
execute align xzy positioned ~0.5 ~ ~0.5 as @e[tag=Puzzle_Box,distance=..0.1] run tag @s add Puzzle_BoxLock
execute align xzy positioned ~0.5 ~ ~0.5 as @e[tag=Puzzle_Box,distance=..0.1] run tag @s remove Puzzle_BoxPush
execute align xzy positioned ~0.5 ~ ~0.5 if entity @e[tag=Puzzle_Box,distance=..0.1] run tag @s add Puzzle_BoxStopRay

execute as @s[distance=..6] positioned ^ ^ ^0.5 if block ~ ~ ~ air unless entity @s[tag=Puzzle_BoxStopRay] run function magic:misc/spells/lock_spell
tag @s remove Puzzle_BoxStopRay