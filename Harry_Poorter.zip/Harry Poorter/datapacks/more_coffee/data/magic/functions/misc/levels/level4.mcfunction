# init
scoreboard players set .boxEnd levels 3
kill @e[tag=levels_entity,tag=!puzzle1]
summon minecraft:armor_stand -102 -40 149 {Tags:["Puzzle_Box","levels_entity"],Invulnerable:1b,DisabledSlots:4144959,Marker:0b,Invisible:1b,ArmorItems:[{},{},{},{id:"minecraft:cake",Count:1b}]}

summon minecraft:armor_stand -102 -38 149 {Tags:["Puzzle_Box","levels_entity"],Invulnerable:1b,DisabledSlots:4144959,Marker:0b,Invisible:1b,ArmorItems:[{},{},{},{id:"minecraft:cake",Count:1b}]}
summon minecraft:armor_stand -107 -43 149 {Tags:["Puzzle_Box","levels_entity"],Invulnerable:1b,DisabledSlots:4144959,Marker:0b,Invisible:1b,ArmorItems:[{},{},{},{id:"minecraft:cake",Count:1b}]}

# blocks
setblock -110 -41 149 minecraft:smooth_stone
setblock -108 -40 149 minecraft:smooth_stone
fill -107 -43 156 -107 -42 156 smooth_stone
fill -100 -41 148 -100 -41 150 smooth_stone
setblock -102 -41 149 minecraft:smooth_stone
fill -107 -42 146 -107 -43 146 minecraft:smooth_stone
fill -100 -41 148 -100 -43 150 smooth_stone

# ends
setblock -107 -44 155 minecraft:stripped_mangrove_log[axis=y]
setblock -108 -44 146 minecraft:stripped_mangrove_log[axis=y]
setblock -100 -42 149 minecraft:stripped_mangrove_log[axis=x]

# reset
scoreboard players set .loaded levels 1