#summon minecraft:text_display -149 -46.2 68 {text:'{"text":"\\\\/","color":"yellow","bold":"true"}',Tags:["potions_CauldronText","potions_entity","potions_Cauldron"],billboard:"vertical",background:0b}
#summon minecraft:text_display -149 -46 68 {text:'{"text":"|","color":"yellow","bold":"true"}',Tags:["potions_CauldronText","potions_entity","potions_Cauldron"],billboard:"vertical",background:0b}
#summon minecraft:text_display -149 -45.8 68 {text:'{"text":"|","color":"yellow","bold":"true"}',Tags:["potions_CauldronText","potions_entity","potions_Cauldron"],billboard:"vertical",background:0b}
summon minecraft:text_display -148 -44.5 70 {text:'{"text":"Stwórz potkę używając\\nrzeczy z tej klasy.","color":"yellow","bold":"true"}',Tags:["potions_entity","potions_Cauldron"],billboard:"vertical",background:0b}

summon minecraft:interaction -149 -48 68 {width:1.25f,height:1.25f,Tags:["potions_CauldronInteraction","potions_entity","potions_Cauldron"],response:1b}

# items
summon minecraft:item_display -153.53 -46.5 63.53 {item:{id:"minecraft:cooked_mutton",Count:1b},Tags:["potions_item1","potions_entity","potions_Cauldron","potion_item"]}
summon minecraft:interaction -153.53 -47.0 63.53 {width:1f,height:1f,Tags:["potions_item1Interaction","potions_entity","potions_Cauldron"],response:1b}

summon minecraft:item_display -143.46 -46.5 63.44 {item:{id:"minecraft:chicken",Count:1b},Tags:["potions_item2","potions_entity","potions_Cauldron","potion_item"]}
summon minecraft:interaction -143.46 -47.0 63.44 {width:1f,height:1f,Tags:["potions_item2Interaction","potions_entity","potions_Cauldron"],response:1b}

summon minecraft:item_display -155.59 -47.5 70.61 {item:{id:"minecraft:mutton",Count:1b},Tags:["potions_item3","potions_entity","potions_Cauldron","potion_item"]}
summon minecraft:interaction -155.59 -48.0 70.61 {width:1f,height:1f,Tags:["potions_item3Interaction","potions_entity","potions_Cauldron"],response:1b}

tag @s add chemistry_init