scoreboard players add pd Fight 1

execute if score pd Fight matches 1 run clear @s

execute if score pd Fight matches 20 run tellraw @s [{"text":"<Uczniowie Hudgeward>","color":"red"},{"color":"gray","text":" ez win L lmao UwU!!11!"}]
execute if score pd Fight matches 60 run tellraw @s [{"text":"<Harry Poorter>","color":"aqua"},{"color":"gray","text":" Nieeee......"}]

execute if score pd Fight matches 70 run title @s times 10 20 10
execute if score pd Fight matches 70 run title @s title {"text":"\uE000"}

execute if score pd Fight matches 90 run title @s times 0 20 0
execute if score pd Fight matches 90 run title @s title {"text":"Umarłeś","color":"red","bold":"true"}
execute if score pd Fight matches 90 run playsound minecraft:meme1 master @s ~ ~ ~ 5 1

execute if score pd Fight matches 110 run title @s times 0 20 10
execute if score pd Fight matches 110 run title @s title {"text":"Spróbuj ponownie!","color":"red","bold":"true"}
execute if score pd Fight matches 110 run playsound minecraft:meme1 master @s ~ ~ ~ 5 1

execute if score pd Fight matches 140.. run function magic:misc/fight/init
execute if score pd Fight matches 140.. run scoreboard players reset pd Fight