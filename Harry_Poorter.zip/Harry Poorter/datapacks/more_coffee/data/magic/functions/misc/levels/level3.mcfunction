# init
scoreboard players set .boxEnd levels 1
kill @e[tag=levels_entity,tag=!puzzle1]
summon minecraft:armor_stand -102 -40 152 {Tags:["Puzzle_Box","levels_entity"],Invulnerable:1b,DisabledSlots:4144959,Marker:0b,Invisible:1b,ArmorItems:[{},{},{},{id:"minecraft:cake",Count:1b}]}

summon minecraft:armor_stand -105 -43 151 {Tags:["Puzzle_Box","levels_entity"],Invulnerable:1b,DisabledSlots:4144959,Marker:0b,Invisible:1b,ArmorItems:[{},{},{},{id:"minecraft:cake",Count:1b}]}
summon minecraft:armor_stand -108 -43 155 {Tags:["Puzzle_Box","levels_entity"],Invulnerable:1b,DisabledSlots:4144959,Marker:0b,Invisible:1b,ArmorItems:[{},{},{},{id:"minecraft:cake",Count:1b}]}

# blocks
setblock -102 -41 152 minecraft:smooth_stone
setblock -105 -43 152 minecraft:smooth_stone
setblock -109 -43 149 minecraft:smooth_stone
setblock -103 -43 146 minecraft:smooth_stone
setblock -109 -44 147 minecraft:stripped_mangrove_log[axis=y]

# reset
scoreboard players set .loaded levels 1