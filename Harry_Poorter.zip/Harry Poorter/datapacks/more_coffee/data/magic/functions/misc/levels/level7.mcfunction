# init
scoreboard players set .boxEnd levels 5
kill @e[tag=levels_entity,tag=!puzzle1]
summon minecraft:armor_stand -103 -42 155 {Tags:["Puzzle_Box","levels_entity"],Invulnerable:1b,DisabledSlots:4144959,Marker:0b,Invisible:1b,ArmorItems:[{},{},{},{id:"minecraft:cake",Count:1b}]}

summon minecraft:armor_stand -103 -42 154 {Tags:["Puzzle_Box","levels_entity"],Invulnerable:1b,DisabledSlots:4144959,Marker:0b,Invisible:1b,ArmorItems:[{},{},{},{id:"minecraft:cake",Count:1b}]}
summon minecraft:armor_stand -103 -40 153 {Tags:["Puzzle_Box","levels_entity"],Invulnerable:1b,DisabledSlots:4144959,Marker:0b,Invisible:1b,ArmorItems:[{},{},{},{id:"minecraft:cake",Count:1b}]}
summon minecraft:armor_stand -101 -42 148 {Tags:["Puzzle_Box","levels_entity"],Invulnerable:1b,DisabledSlots:4144959,Marker:0b,Invisible:1b,ArmorItems:[{},{},{},{id:"minecraft:cake",Count:1b}]}
summon minecraft:armor_stand -101 -39 147 {Tags:["Puzzle_Box","levels_entity"],Invulnerable:1b,DisabledSlots:4144959,Marker:0b,Invisible:1b,ArmorItems:[{},{},{},{id:"minecraft:cake",Count:1b}]}
summon minecraft:armor_stand -109 -38 154 {Tags:["Puzzle_Box","levels_entity"],Invulnerable:1b,DisabledSlots:4144959,Marker:0b,Invisible:1b,ArmorItems:[{},{},{},{id:"minecraft:cake",Count:1b}]}
summon minecraft:armor_stand -108 -43 151 {Tags:["Puzzle_Box","levels_entity"],Invulnerable:1b,DisabledSlots:4144959,Marker:0b,Invisible:1b,ArmorItems:[{},{},{},{id:"minecraft:cake",Count:1b}]}

# blocks
fill -102 -43 156 -104 -41 156 smooth_stone
setblock -110 -40 150 minecraft:smooth_stone
setblock -103 -43 146 minecraft:smooth_stone
fill -101 -43 146 -101 -42 146 minecraft:smooth_stone
setblock -109 -43 147 minecraft:smooth_stone
setblock -109 -38 152 minecraft:smooth_stone
setblock -101 -43 148 minecraft:smooth_stone
setblock -106 -43 151 minecraft:smooth_stone
setblock -106 -43 155 minecraft:smooth_stone
setblock -104 -43 149 minecraft:smooth_stone
setblock -107 -43 148 minecraft:smooth_stone
fill -109 -42 146 -109 -43 146 minecraft:smooth_stone
setblock -106 -39 147 minecraft:smooth_stone
fill -109 -39 154 -109 -39 153 minecraft:brown_glazed_terracotta
setblock -103 -41 153 minecraft:brown_glazed_terracotta[facing=north]
setblock -101 -40 147 minecraft:brown_glazed_terracotta[facing=south]
fill -103 -43 154 -103 -43 155 minecraft:smooth_stone
fill -110 -41 155 -110 -43 154 minecraft:smooth_stone
setblock -109 -43 155 minecraft:smooth_stone
setblock -110 -41 151 minecraft:brown_glazed_terracotta[facing=east]

# ends
setblock -103 -42 156 minecraft:stripped_mangrove_log[axis=z]
setblock -104 -44 154 minecraft:stripped_mangrove_log[axis=y]
setblock -103 -44 153 minecraft:stripped_mangrove_log[axis=y]
setblock -109 -44 154 minecraft:stripped_mangrove_log[axis=y]
setblock -106 -44 147 minecraft:stripped_mangrove_log[axis=y]

# reset
scoreboard players set .loaded levels 1