tag @s add fight_system

bossbar set minecraft:guys value 100
bossbar set minecraft:guys players @s
bossbar set minecraft:guys visible true

bossbar set minecraft:player value 100
bossbar set minecraft:player players @s
bossbar set minecraft:player visible true

tellraw @s [{"text":"---==== * ====---\n","color":"gray"},{"text":"Jest to turowy system walki.\nSpróbuj zgadnąć jakie zaklęcie rzuci przeciwnik i pokonaj je swoim!\nNaciśnij [Q] aby rzucić zaklęcie!","color":"yellow"},{"text":"\n---==== * ====---","color":"gray"}]

function magic:misc/fight/items

scoreboard players set enemy Fight 1
scoreboard players set php Fight 100
scoreboard players set ehp Fight 100