scoreboard players add enemytim Fight 1

execute if score enemytim Fight matches 20..80 run particle end_rod -178.0 -46.0 95.0 0.5 0.5 0.5 0.5 5 force @a

execute if score enemytim Fight matches 20 run tellraw @s [{"text":"<Uczniowie Hudgeward>","color":"red"},{"color":"gray","text":" Podziwiaj naszą nadzwyczają tarczę!"}]
execute if score enemytim Fight matches 60 run tellraw @s [{"text":"<Uczniowie Hudgeward>","color":"red"},{"color":"gray","text":" UDERZAJĄCAAA...."}]
execute if score enemytim Fight matches 80 run tellraw @s [{"text":"<Uczniowie Hudgeward>","color":"red"},{"color":"gray","text":" TARCZAAAA!!!!"}]

execute if score enemytim Fight matches 80 run fill -177 -48 94 -180 -46 94 minecraft:light_blue_stained_glass
execute if score enemytim Fight matches 80 run particle flash -178.0 -46.0 95.0 0.5 0.5 0.5 0.5 5 force @a
execute if score enemytim Fight matches 80 run particle sweep_attack -178.0 -46.0 95.0 0.5 0.5 0.5 0.5 5 force @a
execute if score enemytim Fight matches 80 run playsound minecraft:block.conduit.deactivate master @s ~ ~ ~ 5 1

execute if score enemytim Fight matches 110 run playsound minecraft:entity.generic.explode master @s ~ ~ ~ 5 2
execute if score enemytim Fight matches 110 run particle minecraft:explosion -178.0 -45.5 87.0 0.5 0.5 0.5 0.5 3 force @a
execute if score enemytim Fight matches 110 run summon minecraft:fireball -178.0 -45.5 87.0 {power:[0.0,0.0,0.1],ExplosionPower:1}

execute if score enemytim Fight matches 125 run fill -177 -48 94 -180 -46 94 minecraft:air destroy
execute if score enemytim Fight matches 125 run fill -178 -48 94 -180 -48 94 minecraft:red_carpet

execute if score enemytim Fight matches 130 run particle minecraft:block redstone_block -178.0 -46.0 95.0 0.5 0.5 0.5 0.5 50 force @a
execute if score enemytim Fight matches 125 run particle minecraft:explosion_emitter -178.0 -46.0 95.0 0.5 0.5 0.5 0.5 3 force @a
execute if score enemytim Fight matches 130 run playsound minecraft:entity.player.hurt master @s ~ ~ ~ 5 1

execute if score enemytim Fight matches 150.. run function magic:misc/fight/player/reset
execute if score enemytim Fight matches 150.. run tag @s remove enemy_turn
execute if score enemytim Fight matches 150.. run tag @s add deal_dmg
execute if score enemytim Fight matches 150.. run scoreboard players reset enemytim Fight