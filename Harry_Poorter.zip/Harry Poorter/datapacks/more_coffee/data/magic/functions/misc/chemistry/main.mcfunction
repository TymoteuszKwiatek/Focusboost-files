# init cauldron
execute if entity @s[tag=!chemistry_init] run function magic:misc/chemistry/init

# interaction
execute as @e[tag=potions_CauldronInteraction] if data entity @s interaction run function magic:misc/chemistry/interaction
execute as @e[tag=potions_CauldronInteraction] if data entity @s interaction run data remove entity @s interaction

execute as @e[tag=potions_CauldronInteraction] if data entity @s attack run function magic:misc/chemistry/interaction
execute as @e[tag=potions_CauldronInteraction] if data entity @s attack run data remove entity @s attack

# pickup items
execute as @e[tag=potions_item1Interaction] if data entity @s interaction on target run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 10000 2
execute as @e[tag=potions_item1Interaction] if data entity @s interaction on target run give @s cooked_mutton{display:{Name:'{"text":"Klapek","bold":"true","color":"#a69e88"}'},potion_item:1b} 1
execute as @e[tag=potions_item1Interaction] if data entity @s interaction run kill @e[tag=potions_item1]
execute as @e[tag=potions_item1Interaction] if data entity @s interaction run kill @s

execute as @e[tag=potions_item1Interaction] if data entity @s attack on attacker run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 10000 2
execute as @e[tag=potions_item1Interaction] if data entity @s attack on attacker run give @s cooked_mutton{display:{Name:'{"text":"Klapek","bold":"true","color":"#a69e88"}'},potion_item:1b} 1
execute as @e[tag=potions_item1Interaction] if data entity @s attack run kill @e[tag=potions_item1]
execute as @e[tag=potions_item1Interaction] if data entity @s attack run kill @s

execute as @e[tag=potions_item2Interaction] if data entity @s interaction on target run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 10000 2
execute as @e[tag=potions_item2Interaction] if data entity @s interaction on target run give @s chicken{display:{Name:'{"text":"Puszka","bold":"true","color":"#5ea0e6"}'},potion_item:1b} 1
execute as @e[tag=potions_item2Interaction] if data entity @s interaction run kill @e[tag=potions_item2]
execute as @e[tag=potions_item2Interaction] if data entity @s interaction run kill @s

execute as @e[tag=potions_item2Interaction] if data entity @s attack on attacker run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 10000 2
execute as @e[tag=potions_item2Interaction] if data entity @s attack on attacker run give @s chicken{display:{Name:'{"text":"Puszka","bold":"true","color":"#5ea0e6"}'},potion_item:1b} 1
execute as @e[tag=potions_item2Interaction] if data entity @s attack run kill @e[tag=potions_item2]
execute as @e[tag=potions_item2Interaction] if data entity @s attack run kill @s

execute as @e[tag=potions_item3Interaction] if data entity @s interaction on target run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 10000 2
execute as @e[tag=potions_item3Interaction] if data entity @s interaction on target run give @s mutton{display:{Name:'{"text":"Szczur","bold":"true","color":"#ab0f31"}'},potion_item:1b} 1
execute as @e[tag=potions_item3Interaction] if data entity @s interaction run kill @e[tag=potions_item3]
execute as @e[tag=potions_item3Interaction] if data entity @s interaction run kill @s

execute as @e[tag=potions_item3Interaction] if data entity @s attack on attacker run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 10000 2
execute as @e[tag=potions_item3Interaction] if data entity @s attack on attacker run give @s mutton{display:{Name:'{"text":"Szczur","bold":"true","color":"#ab0f31"}'},potion_item:1b} 1
execute as @e[tag=potions_item3Interaction] if data entity @s attack run kill @e[tag=potions_item3]
execute as @e[tag=potions_item3Interaction] if data entity @s attack run kill @s


# done
execute if score .items potions matches 3.. run tag @s remove potions_gameplay
execute if score .items potions matches 3.. run tag @s add potions2
execute if score .items potions matches 3.. run tag @s remove chemistry_init
execute if score .items potions matches 3.. run kill @e[tag=potions_Cauldron]
execute if score .items potions matches 3.. run scoreboard players reset .items potions