scoreboard players add enemytim Fight 1

execute if score enemytim Fight matches 20..80 run particle flame -178.0 -46.0 95.0 0.5 0.5 0.5 0.5 5 force @a

execute if score enemytim Fight matches 20 run tellraw @s [{"text":"<Uczniowie Hudgeward>","color":"red"},{"color":"gray","text":" Posmakuj naszej ostatecznej mocy!"}]
execute if score enemytim Fight matches 60 run tellraw @s [{"text":"<Uczniowie Hudgeward>","color":"red"},{"color":"gray","text":" KULA...."}]
execute if score enemytim Fight matches 80 run tellraw @s [{"text":"<Uczniowie Hudgeward>","color":"red"},{"color":"gray","text":" OGNIAAAAA!!!!"}]

execute if score enemytim Fight matches 80 run summon minecraft:fireball -178.0 -46.0 95.0 {power:[0.0,0.0,-0.5],ExplosionPower:1}
execute if score enemytim Fight matches 80 run playsound minecraft:item.firecharge.use master @s ~ ~ ~ 5 1
execute if score enemytim Fight matches 80 run particle lava -178.0 -46.0 95.0 0.5 0.5 0.5 0.1 25 force @a
execute if score enemytim Fight matches 80 run particle flame -178.0 -46.0 95.0 0.5 0.5 0.5 0.5 50 force @a
execute if score enemytim Fight matches 80 run particle flash -178.0 -46.0 95.0 0 0 0 0.1 1 force @a

execute if score enemytim Fight matches 90 run particle minecraft:explosion_emitter -178.04 -46.89 83.65 0 0 0 0.1 3 force @a

execute if score enemytim Fight matches 120.. run function magic:misc/fight/player/reset
execute if score enemytim Fight matches 120.. run tag @s remove enemy_turn
execute if score enemytim Fight matches 120.. run tag @s add hurt
execute if score enemytim Fight matches 120.. run scoreboard players reset enemytim Fight