scoreboard players add enemytim Fight 1

execute if score enemytim Fight matches 20..80 run particle happy_villager -178.0 -46.0 95.0 0.5 0.5 0.5 0.5 5 force @a

execute if score enemytim Fight matches 20 run tellraw @s [{"text":"<Uczniowie Hudgeward>","color":"red"},{"color":"gray","text":" Przekonaj się, że jesteśmy lepsi!"}]
execute if score enemytim Fight matches 60 run tellraw @s [{"text":"<Uczniowie Hudgeward>","color":"red"},{"color":"gray","text":" BLOKKKKK...."}]
execute if score enemytim Fight matches 80 run tellraw @s [{"text":"<Uczniowie Hudgeward>","color":"red"},{"color":"gray","text":" DIRTAAAAAA!!!!"}]

execute if score enemytim Fight matches 80 run playsound minecraft:entity.illusioner.cast_spell master @s ~ ~ ~ 5 1
execute if score enemytim Fight matches 80 run summon minecraft:armor_stand -179 -48 94 {NoGravity:1,Invulnerable:1,Invisible:1,Tags:["dirt_block","fight_model"],ArmorItems:[{},{},{},{id:"minecraft:dirt",Count:1b}]}

execute if score enemytim Fight matches 80..91 as @e[tag=dirt_block] at @s run tp @s ~ ~ ~-1
execute if score enemytim Fight matches 80..90 as @e[tag=dirt_block] at @s run particle minecraft:block dirt ~ ~1 ~ 0.5 0.5 0.5 0.5 100 force @a
execute if score enemytim Fight matches 80..90 as @e[tag=dirt_block] at @s run particle minecraft:dust 0.2 0.01 0.01 2 ~ ~1 ~ 0.5 0.5 0.5 0.5 50 force @a

execute if score enemytim Fight matches 91 run particle minecraft:explosion_emitter -178.04 -46.89 83.65 0 0 0 0.1 3 force @a
execute if score enemytim Fight matches 91 run playsound minecraft:entity.generic.explode master @s ~ ~ ~ 5 1
execute if score enemytim Fight matches 91 run kill @e[tag=dirt_block]

execute if score enemytim Fight matches 120.. run function magic:misc/fight/player/reset
execute if score enemytim Fight matches 120.. run tag @s remove enemy_turn
execute if score enemytim Fight matches 120.. run tag @s add hurt
execute if score enemytim Fight matches 120.. run scoreboard players reset enemytim Fight