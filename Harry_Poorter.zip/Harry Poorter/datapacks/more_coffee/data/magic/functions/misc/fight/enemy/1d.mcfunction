scoreboard players add enemytim Fight 1

execute if score enemytim Fight matches 20..80 run particle flame -178.0 -46.0 95.0 0.5 0.5 0.5 0.5 5 force @a

execute if score enemytim Fight matches 20 run tellraw @s [{"text":"<Uczniowie Hudgeward>","color":"red"},{"color":"gray","text":" Posmakuj naszej ostatecznej mocy!"}]
execute if score enemytim Fight matches 60 run tellraw @s [{"text":"<Uczniowie Hudgeward>","color":"red"},{"color":"gray","text":" KULAAA...."}]
execute if score enemytim Fight matches 80 run tellraw @s [{"text":"<Uczniowie Hudgeward>","color":"red"},{"color":"gray","text":" OGNIAAAAA!!!!"}]

execute if score enemytim Fight matches 80 run summon minecraft:fireball -178.0 -46.0 95.0 {power:[0.0,0.0,-0.05],ExplosionPower:1,Tags:["slurp_ball"]}

execute if score enemytim Fight matches 100 run playsound minecraft:entity.generic.drink master @s ~ ~ ~ 5 0
execute if score enemytim Fight matches 100 run particle minecraft:splash -178 -46 85 1 1 1 0.1 1000 force @a
execute if score enemytim Fight matches 100 run kill @e[tag=slurp_ball]

execute if score enemytim Fight matches 150 run particle minecraft:block water -177.5 -46 89.0 0 0 3 0 1000 force @a
execute if score enemytim Fight matches 150 run playsound minecraft:entity.generic.explode master @s ~ ~ ~ 5 1
execute if score enemytim Fight matches 150 run particle minecraft:explosion -177.5 -47.0 95.5 0.3 0.3 0.3 0.5 4 force @a
execute if score enemytim Fight matches 150 run particle minecraft:flash -178.0 -46 85.0 0 0 0 0 1 force @a
execute if score enemytim Fight matches 150 run particle minecraft:block redstone_block -178.0 -46.0 95.0 0.5 0.5 0.5 0.5 50 force @a

execute if score enemytim Fight matches 170.. run function magic:misc/fight/player/reset
execute if score enemytim Fight matches 170.. run tag @s remove enemy_turn
execute if score enemytim Fight matches 170.. run tag @s add deal_dmg
execute if score enemytim Fight matches 170.. run scoreboard players reset enemytim Fight