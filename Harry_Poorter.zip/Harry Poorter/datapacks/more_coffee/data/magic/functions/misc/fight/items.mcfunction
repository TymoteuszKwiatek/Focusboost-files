clear @s

item replace entity @s container.0 with minecraft:fire_charge{display:{Name:'{"text":"Ogień","bold":"true","italic":"false","color":"gold"}'},FightAtt:1,FightItem:1b}
item replace entity @s container.2 with minecraft:water_bucket{display:{Name:'{"text":"Woda","bold":"true","italic":"false","color":"aqua"}'},FightAtt:2,FightItem:1b}
item replace entity @s container.4 with minecraft:grass_block{display:{Name:'{"text":"Ziemia","bold":"true","italic":"false","color":"green"}'},FightAtt:3,FightItem:1b}
item replace entity @s container.6 with minecraft:golden_sword{display:{Name:'{"text":"Siła","bold":"true","italic":"false","color":"yellow"}'},FightAtt:4,FightItem:1b}
item replace entity @s container.8 with minecraft:red_bed{display:{Name:'{"text":"Tarcza","bold":"true","italic":"false","color":"dark_red"}'},FightAtt:5,FightItem:1b}