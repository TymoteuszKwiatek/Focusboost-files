tag @s remove Puzzle_BoxLock
data merge entity @s {NoGravity:0b}
scoreboard players reset @s Lock_Spell