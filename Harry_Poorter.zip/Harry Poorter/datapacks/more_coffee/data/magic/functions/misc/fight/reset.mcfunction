kill @e[tag=fight_model]
kill @e[tag=fight_cam]

scoreboard players reset lacrimosa Text

tag @s remove lacrimosa
tag @s remove fight_system

stopsound @s * minecraft:lacrimosa

bossbar set minecraft:guys visible false
bossbar set minecraft:player visible false

setblock -178 -48 85 minecraft:red_carpet
setblock -178 -47 85 minecraft:air
fill -177 -48 86 -177 -48 85 minecraft:air

fill -151 -48 86 -148 -44 86 minecraft:air