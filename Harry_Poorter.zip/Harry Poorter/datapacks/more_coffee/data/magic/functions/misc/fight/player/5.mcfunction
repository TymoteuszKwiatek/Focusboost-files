scoreboard players add player Fight 1

execute if score player Fight matches 1 run gamerule doTileDrops false

execute if score player Fight matches 20 run setblock -177 -48 86 minecraft:red_bed[facing=north,occupied=false,part=foot]{}
execute if score player Fight matches 20 run setblock -177 -48 85 minecraft:red_bed[facing=north,occupied=false,part=head]{}
execute if score player Fight matches 20 run playsound minecraft:block.wood.place master @s ~ ~ ~ 5 0

execute if score player Fight matches 60 run particle minecraft:heart -176.49 -47.44 85.99 1 1 1 0.01 100 force @a
execute if score player Fight matches 60 run playsound minecraft:entity.wolf.whine master @s ~ ~ ~ 5 1

execute if score player Fight matches 90.. run tag @s add enemy_turn
execute if score player Fight matches 90.. run scoreboard players reset player Fight