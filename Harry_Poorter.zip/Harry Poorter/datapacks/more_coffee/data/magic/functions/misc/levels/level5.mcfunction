# init
scoreboard players set .boxEnd levels 3
kill @e[tag=levels_entity,tag=!puzzle1]
summon minecraft:armor_stand -101 -40 155 {Tags:["Puzzle_Box","levels_entity"],Invulnerable:1b,DisabledSlots:4144959,Marker:0b,Invisible:1b,ArmorItems:[{},{},{},{id:"minecraft:cake",Count:1b}]}

summon minecraft:armor_stand -101 -40 156 {Tags:["Puzzle_Box","levels_entity"],Invulnerable:1b,DisabledSlots:4144959,Marker:0b,Invisible:1b,ArmorItems:[{},{},{},{id:"minecraft:cake",Count:1b}]}
summon minecraft:armor_stand -100 -40 155 {Tags:["Puzzle_Box","levels_entity"],Invulnerable:1b,DisabledSlots:4144959,Marker:0b,Invisible:1b,ArmorItems:[{},{},{},{id:"minecraft:cake",Count:1b}]}
summon minecraft:armor_stand -100 -40 156 {Tags:["Puzzle_Box","levels_entity"],Invulnerable:1b,DisabledSlots:4144959,Marker:0b,Invisible:1b,ArmorItems:[{},{},{},{id:"minecraft:cake",Count:1b}]}

# blocks
fill -110 -43 156 -110 -41 156 smooth_stone
setblock -106 -43 146 minecraft:smooth_stone
setblock -105 -43 153 minecraft:smooth_stone
setblock -101 -43 151 minecraft:smooth_stone
fill -100 -41 155 -101 -41 156 minecraft:brown_glazed_terracotta

# ends
setblock -101 -44 152 minecraft:stripped_mangrove_log[axis=y]
setblock -102 -44 152 minecraft:stripped_mangrove_log[axis=y]
setblock -107 -44 155 minecraft:stripped_mangrove_log[axis=y]

# reset
scoreboard players set .loaded levels 1