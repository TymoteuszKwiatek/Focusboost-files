execute unless score attstor Fight matches 0 run clear @s

execute if score att Fight matches 1 run function magic:misc/fight/player/1
execute if score att Fight matches 2 run function magic:misc/fight/player/2
execute if score att Fight matches 3 run function magic:misc/fight/player/3
execute if score att Fight matches 4 run function magic:misc/fight/player/4
execute if score att Fight matches 5 run function magic:misc/fight/player/5