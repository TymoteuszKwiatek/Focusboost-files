# init
scoreboard players set .boxEnd levels 8
kill @e[tag=levels_entity,tag=!puzzle1]
summon minecraft:armor_stand -101 -41 155 {Tags:["Puzzle_Box","levels_entity"],Invulnerable:1b,DisabledSlots:4144959,Marker:0b,Invisible:1b,ArmorItems:[{},{},{},{id:"minecraft:cake",Count:1b}]}
summon minecraft:armor_stand -101 -36 155 {Tags:["Puzzle_Box","levels_entity"],Invulnerable:1b,DisabledSlots:4144959,Marker:0b,Invisible:1b,ArmorItems:[{},{},{},{id:"minecraft:cake",Count:1b}]}
summon minecraft:armor_stand -101 -34 155 {Tags:["Puzzle_Box","levels_entity"],Invulnerable:1b,DisabledSlots:4144959,Marker:0b,Invisible:1b,ArmorItems:[{},{},{},{id:"minecraft:cake",Count:1b}]}
summon minecraft:armor_stand -105 -39 155 {Tags:["Puzzle_Box","levels_entity"],Invulnerable:1b,DisabledSlots:4144959,Marker:0b,Invisible:1b,ArmorItems:[{},{},{},{id:"minecraft:cake",Count:1b}]}
summon minecraft:armor_stand -107 -41 155 {Tags:["Puzzle_Box","levels_entity"],Invulnerable:1b,DisabledSlots:4144959,Marker:0b,Invisible:1b,ArmorItems:[{},{},{},{id:"minecraft:cake",Count:1b}]}
summon minecraft:armor_stand -110 -43 153 {Tags:["Puzzle_Box","levels_entity"],Invulnerable:1b,DisabledSlots:4144959,Marker:0b,Invisible:1b,ArmorItems:[{},{},{},{id:"minecraft:cake",Count:1b}]}
summon minecraft:armor_stand -110 -40 146 {Tags:["Puzzle_Box","levels_entity"],Invulnerable:1b,DisabledSlots:4144959,Marker:0b,Invisible:1b,ArmorItems:[{},{},{},{id:"minecraft:cake",Count:1b}]}
summon minecraft:armor_stand -105 -39 147 {Tags:["Puzzle_Box","levels_entity"],Invulnerable:1b,DisabledSlots:4144959,Marker:0b,Invisible:1b,ArmorItems:[{},{},{},{id:"minecraft:cake",Count:1b}]}
summon minecraft:armor_stand -104 -40 149 {Tags:["Puzzle_Box","levels_entity"],Invulnerable:1b,DisabledSlots:4144959,Marker:0b,Invisible:1b,ArmorItems:[{},{},{},{id:"minecraft:cake",Count:1b}]}
summon minecraft:armor_stand -104 -40 150 {Tags:["Puzzle_Box","levels_entity"],Invulnerable:1b,DisabledSlots:4144959,Marker:0b,Invisible:1b,ArmorItems:[{},{},{},{id:"minecraft:cake",Count:1b}]}
summon minecraft:armor_stand -101 -40 147 {Tags:["Puzzle_Box","levels_entity"],Invulnerable:1b,DisabledSlots:4144959,Marker:0b,Invisible:1b,ArmorItems:[{},{},{},{id:"minecraft:cake",Count:1b}]}
summon minecraft:armor_stand -105 -41 152 {Tags:["Puzzle_Box","levels_entity"],Invulnerable:1b,DisabledSlots:4144959,Marker:0b,Invisible:1b,ArmorItems:[{},{},{},{id:"minecraft:cake",Count:1b}]}

# blocks
fill -110 -43 149 -110 -42 149 minecraft:smooth_stone
fill -105 -40 147 -105 -43 147 smooth_stone
setblock -108 -43 146 minecraft:smooth_stone
fill -100 -43 147 -100 -41 147 smooth_stone
fill -104 -41 149 -104 -41 150 smooth_stone
setblock -107 -43 152 minecraft:smooth_stone
setblock -105 -42 152 minecraft:smooth_stone
setblock -110 -41 146 minecraft:smooth_stone
setblock -108 -43 154 minecraft:smooth_stone
setblock -110 -43 146 minecraft:smooth_stone
setblock -105 -43 155 minecraft:smooth_stone
setblock -101 -43 152 minecraft:smooth_stone
setblock -102 -41 152 minecraft:smooth_stone
setblock -101 -42 155 minecraft:smooth_stone
setblock -103 -43 154 minecraft:smooth_stone
setblock -107 -42 155 minecraft:smooth_stone
fill -108 -41 155 -108 -40 155 smooth_stone
setblock -105 -40 155 minecraft:brown_glazed_terracotta[facing=north]
setblock -101 -37 155 minecraft:brown_glazed_terracotta[facing=north]
setblock -101 -41 147 minecraft:brown_glazed_terracotta[facing=north]
fill -109 -38 154 -109 -40 156 smooth_stone
setblock -105 -40 147 air

# ends
setblock -109 -39 155 minecraft:stripped_mangrove_log[axis=x]
setblock -110 -41 149 minecraft:stripped_mangrove_log[axis=y]
setblock -110 -42 146 minecraft:stripped_mangrove_log[axis=z]
setblock -105 -44 154 minecraft:stripped_mangrove_log[axis=y]
setblock -104 -44 148 minecraft:stripped_mangrove_log[axis=y]
setblock -101 -44 147 minecraft:stripped_mangrove_log[axis=y]
setblock -102 -44 153 minecraft:stripped_mangrove_log[axis=y]
setblock -101 -44 155 minecraft:stripped_mangrove_log[axis=y]

# reset
scoreboard players set .loaded levels 1