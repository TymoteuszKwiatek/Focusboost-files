scoreboard players add ed Fight 1

execute if score ed Fight matches 1 run clear @s

execute if score ed Fight matches 20 run tellraw @s [{"text":"<Harry Poorter>","color":"aqua"},{"color":"gray","text":" ez win L lmao UwU!!11!"}]
execute if score ed Fight matches 60 run tellraw @s [{"text":"<Uczniowie Hudgeward>","color":"red"},{"color":"gray","text":" Nieeee......"}]

execute if score ed Fight matches 80 run kill @e[tag=fight_enemy2]
execute if score ed Fight matches 80 run particle minecraft:poof -177.5 -46.0 95.5 0.5 0.5 0.3 0.05 50 force @a
execute if score ed Fight matches 80 run playsound minecraft:meme14 master @s ~ ~ ~ 5 1

execute if score ed Fight matches 100 run title @s times 10 20 10
execute if score ed Fight matches 100 run title @s title {"text":"\uE000"}

execute if score ed Fight matches 115 run kill @e[tag=fight_model]
execute if score ed Fight matches 115 run kill @e[tag=fight_cam]
execute if score ed Fight matches 115 run fill -151 -48 86 -148 -44 86 minecraft:iron_bars
execute if score ed Fight matches 115 run tp @s -149.0 -48.0 91.5 0 0

execute if score ed Fight matches 130 run title @s times 0 30 10
execute if score ed Fight matches 130 run title @s title {"text":"Zwycięstwo","color":"yellow","bold":"true"}
execute if score ed Fight matches 130 run playsound minecraft:meme1 master @s ~ ~ ~ 5 1

execute if score ed Fight matches 130.. run tag @s remove fight_system
execute if score ed Fight matches 130.. run tag @s remove lacrimosa
execute if score ed Fight matches 130.. run stopsound @s * minecraft:lacrimosa
execute if score ed Fight matches 130.. run bossbar set minecraft:guys visible false
execute if score ed Fight matches 130.. run bossbar set minecraft:player visible false
execute if score ed Fight matches 130.. run scoreboard players reset ed Fight