stopsound @s
tag @s remove levels_gameplay
tag @s add ending_game

title @s times 10 10 10
title @s title {"text":"\uE000"}