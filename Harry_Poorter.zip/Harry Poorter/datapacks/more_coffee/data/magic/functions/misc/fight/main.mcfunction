tp @s @e[tag=fight_cam4,limit=1]

scoreboard players set attstor Fight 0
execute as @e[type=minecraft:item,nbt={Item:{tag:{FightItem:1b}}}] store result score attstor Fight run data get entity @s Item.tag.FightAtt 1
execute unless score attstor Fight matches 0 run scoreboard players operation att Fight = attstor Fight

execute if entity @s[tag=!enemy_turn] run function magic:misc/fight/player/main

kill @e[type=minecraft:item,nbt={Item:{tag:{FightItem:1b}}}]

execute if score enemy Fight matches 1 run particle minecraft:flame -178.0 -47 95.0 0.5 0.5 0.5 0.01 1 force @a
execute if score enemy Fight matches 2 run particle minecraft:splash -178.0 -47 95.0 0.5 0.5 0.5 0.01 1 force @a
execute if score enemy Fight matches 3 run particle minecraft:happy_villager -178.0 -47 95.0 0.5 0.5 0.5 0.01 1 force @a
execute if score enemy Fight matches 4 run particle minecraft:crit -178.0 -47 95.0 0.5 0.5 0.5 0.01 1 force @a
execute if score enemy Fight matches 5 run particle minecraft:end_rod -178.0 -47 95.0 0.5 0.5 0.5 0.01 1 force @a

execute if entity @s[tag=enemy_turn] run function magic:misc/fight/enemy/main

execute if entity @s[tag=deal_dmg] run scoreboard players remove ehp Fight 20
execute if entity @s[tag=deal_dmg] run tag @s remove deal_dmg
execute store result bossbar minecraft:guys value run scoreboard players get ehp Fight

execute if entity @s[tag=hurt] run scoreboard players set php Fight 0
execute if entity @s[tag=hurt] run tag @s remove hurt
execute store result bossbar minecraft:player value run scoreboard players get php Fight

execute if score php Fight matches 0 run function magic:misc/fight/player_die
execute if score ehp Fight matches 0 run function magic:misc/fight/enemy_die

particle minecraft:ash -178 -44 88 5 10 10 0.1 10 force @a