scoreboard players add enemytim Fight 1

execute if score enemytim Fight matches 20..80 run particle end_rod -178.0 -46.0 95.0 0.5 0.5 0.5 0.5 5 force @a

execute if score enemytim Fight matches 20 run tellraw @s [{"text":"<Uczniowie Hudgeward>","color":"red"},{"color":"gray","text":" Podziwiaj naszą nadzwyczają tarczę!"}]
execute if score enemytim Fight matches 60 run tellraw @s [{"text":"<Uczniowie Hudgeward>","color":"red"},{"color":"gray","text":" UDERZAJĄCAAA...."}]
execute if score enemytim Fight matches 80 run tellraw @s [{"text":"<Uczniowie Hudgeward>","color":"red"},{"color":"gray","text":" TARCZAAAA!!!!"}]

execute if score enemytim Fight matches 80 run fill -177 -48 94 -180 -46 94 minecraft:light_blue_stained_glass
execute if score enemytim Fight matches 80 run particle flash -178.0 -46.0 95.0 0.5 0.5 0.5 0.5 5 force @a
execute if score enemytim Fight matches 80 run particle sweep_attack -178.0 -46.0 95.0 0.5 0.5 0.5 0.5 5 force @a
execute if score enemytim Fight matches 80 run playsound minecraft:block.conduit.deactivate master @s ~ ~ ~ 5 1

execute if score enemytim Fight matches 110..120 run particle minecraft:explosion_emitter -178.04 -46.89 83.65 0.5 0.5 0.5 0.1 1 force @a
execute if score enemytim Fight matches 110..120 run particle minecraft:enchanted_hit -177.5 -46 89.0 0 0 3 0.1 200 force @a
execute if score enemytim Fight matches 110..120 run playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 5 1

execute if score enemytim Fight matches 150 run fill -177 -48 94 -180 -46 94 minecraft:air
execute if score enemytim Fight matches 150 run fill -178 -48 94 -180 -48 94 minecraft:red_carpet

execute if score enemytim Fight matches 170.. run function magic:misc/fight/player/reset
execute if score enemytim Fight matches 170.. run tag @s remove enemy_turn
execute if score enemytim Fight matches 170.. run tag @s add hurt
execute if score enemytim Fight matches 170.. run scoreboard players reset enemytim Fight