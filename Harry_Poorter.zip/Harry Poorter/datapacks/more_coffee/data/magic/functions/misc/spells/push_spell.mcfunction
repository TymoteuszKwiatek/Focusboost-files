tag @s remove Puzzle_BoxStopRay
particle minecraft:crit ~ ~ ~ 0 0 0 0 1 force @a
execute align xzy positioned ~0.5 ~ ~0.5 as @e[tag=Puzzle_Box,distance=..0.1] unless score @s Lock_Spell matches 40.. run tag @s add Puzzle_BoxPush
execute align xzy positioned ~0.5 ~ ~0.5 as @e[tag=Puzzle_Box,distance=..0.1] unless score @s Lock_Spell matches 40.. run data merge entity @s {Marker:0b}
execute align xzy positioned ~0.5 ~ ~0.5 if entity @s[y_rotation=135..-135] as @e[tag=Puzzle_Box,distance=..0.1] at @s unless score @s Lock_Spell matches 40.. run data merge entity @s {Rotation:[180f,0f]}
execute align xzy positioned ~0.5 ~ ~0.5 if entity @s[y_rotation=-45..45] as @e[tag=Puzzle_Box,distance=..0.1] at @s unless score @s Lock_Spell matches 40.. run data merge entity @s {Rotation:[0f,0f]}
execute align xzy positioned ~0.5 ~ ~0.5 if entity @s[y_rotation=45..135] as @e[tag=Puzzle_Box,distance=..0.1] at @s unless score @s Lock_Spell matches 40.. run data merge entity @s {Rotation:[90f,0f]}
execute align xzy positioned ~0.5 ~ ~0.5 if entity @s[y_rotation=-135..-45] as @e[tag=Puzzle_Box,distance=..0.1] at @s unless score @s Lock_Spell matches 40.. run data merge entity @s {Rotation:[-90f,0f]}
execute align xzy positioned ~0.5 ~ ~0.5 if entity @e[tag=Puzzle_Box,distance=..0.1] run tag @s add Puzzle_BoxStopRay

execute as @s[distance=..6] positioned ^ ^ ^0.5 if block ~ ~ ~ air unless entity @s[tag=Puzzle_BoxStopRay] run function magic:misc/spells/push_spell
tag @s remove Puzzle_BoxStopRay