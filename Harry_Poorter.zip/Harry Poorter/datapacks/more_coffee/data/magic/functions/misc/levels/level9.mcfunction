# init
scoreboard players set .boxEnd levels 4
kill @e[tag=levels_entity,tag=!puzzle1]
summon minecraft:armor_stand -102 -42 154 {Tags:["Puzzle_Box","levels_entity"],Invulnerable:1b,DisabledSlots:4144959,Marker:0b,Invisible:1b,ArmorItems:[{},{},{},{id:"minecraft:cake",Count:1b}]}
summon minecraft:armor_stand -106 -42 154 {Tags:["Puzzle_Box","levels_entity"],Invulnerable:1b,DisabledSlots:4144959,Marker:0b,Invisible:1b,ArmorItems:[{},{},{},{id:"minecraft:cake",Count:1b}]}
summon minecraft:armor_stand -109 -42 154 {Tags:["Puzzle_Box","levels_entity"],Invulnerable:1b,DisabledSlots:4144959,Marker:0b,Invisible:1b,ArmorItems:[{},{},{},{id:"minecraft:cake",Count:1b}]}
summon minecraft:armor_stand -107 -42 151 {Tags:["Puzzle_Box","levels_entity"],Invulnerable:1b,DisabledSlots:4144959,Marker:0b,Invisible:1b,ArmorItems:[{},{},{},{id:"minecraft:cake",Count:1b}]}


# blocks
setblock -109 -43 154 minecraft:smooth_stone
setblock -106 -43 154 minecraft:smooth_stone
setblock -102 -43 154 minecraft:smooth_stone
setblock -104 -43 146 minecraft:smooth_stone
setblock -106 -42 146 minecraft:smooth_stone
setblock -110 -43 146 minecraft:smooth_stone
setblock -106 -43 149 minecraft:smooth_stone
setblock -105 -42 151 minecraft:smooth_stone
fill -105 -43 151 -107 -43 151 smooth_stone
fill -101 -43 148 -101 -42 148 smooth_stone
fill -102 -43 149 -102 -42 149 smooth_stone
fill -102 -43 149 -102 -42 149 smooth_stone
fill -107 -43 153 -107 -41 154 smooth_stone
fill -107 -43 153 -107 -41 154 smooth_stone
fill -103 -43 152 -103 -41 152 smooth_stone
fill -109 -43 149 -109 -42 149 smooth_stone
fill -104 -41 150 -104 -43 152 smooth_stone

# ends
setblock -109 -44 148 minecraft:stripped_mangrove_log[axis=y]
setblock -106 -44 148 minecraft:stripped_mangrove_log[axis=y]
setblock -102 -44 148 minecraft:stripped_mangrove_log[axis=y]
setblock -100 -44 151 minecraft:stripped_mangrove_log[axis=y]

# reset
scoreboard players set .loaded levels 1