tp @s ~ ~ ~ 0 0
tag @s remove Puzzle_BoxPush