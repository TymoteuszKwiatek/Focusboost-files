# init
scoreboard players set .boxEnd levels 4
kill @e[tag=levels_entity,tag=!puzzle1]
summon minecraft:armor_stand -109 -43 146 {Tags:["Puzzle_Box","levels_entity"],Invulnerable:1b,DisabledSlots:4144959,Marker:0b,Invisible:1b,ArmorItems:[{},{},{},{id:"minecraft:cake",Count:1b}]}
summon minecraft:armor_stand -109 -43 148 {Tags:["Puzzle_Box","levels_entity"],Invulnerable:1b,DisabledSlots:4144959,Marker:0b,Invisible:1b,ArmorItems:[{},{},{},{id:"minecraft:cake",Count:1b}]}
summon minecraft:armor_stand -109 -43 150 {Tags:["Puzzle_Box","levels_entity"],Invulnerable:1b,DisabledSlots:4144959,Marker:0b,Invisible:1b,ArmorItems:[{},{},{},{id:"minecraft:cake",Count:1b}]}
summon minecraft:armor_stand -109 -43 152 {Tags:["Puzzle_Box","levels_entity"],Invulnerable:1b,DisabledSlots:4144959,Marker:0b,Invisible:1b,ArmorItems:[{},{},{},{id:"minecraft:cake",Count:1b}]}
summon minecraft:armor_stand -109 -43 154 {Tags:["Puzzle_Box","levels_entity"],Invulnerable:1b,DisabledSlots:4144959,Marker:0b,Invisible:1b,ArmorItems:[{},{},{},{id:"minecraft:cake",Count:1b}]}
summon minecraft:armor_stand -109 -43 156 {Tags:["Puzzle_Box","levels_entity"],Invulnerable:1b,DisabledSlots:4144959,Marker:0b,Invisible:1b,ArmorItems:[{},{},{},{id:"minecraft:cake",Count:1b}]}

# blocks
setblock -101 -43 147 minecraft:smooth_stone
setblock -104 -43 147 minecraft:smooth_stone
setblock -107 -43 150 minecraft:smooth_stone
setblock -107 -43 153 minecraft:smooth_stone
setblock -107 -43 155 minecraft:smooth_stone
setblock -101 -43 150 minecraft:smooth_stone
setblock -104 -43 153 minecraft:smooth_stone
setblock -101 -43 153 minecraft:smooth_stone
setblock -101 -43 155 minecraft:smooth_stone
setblock -104 -43 155 minecraft:smooth_stone
setblock -110 -43 150 minecraft:smooth_stone
setblock -107 -43 147 minecraft:smooth_stone


# ends
setblock -105 -44 151 minecraft:stripped_mangrove_log[axis=y]
setblock -105 -44 149 minecraft:stripped_mangrove_log[axis=y]
setblock -103 -44 149 minecraft:stripped_mangrove_log[axis=y]
setblock -103 -44 151 minecraft:stripped_mangrove_log[axis=y]

# reset
scoreboard players set .loaded levels 1