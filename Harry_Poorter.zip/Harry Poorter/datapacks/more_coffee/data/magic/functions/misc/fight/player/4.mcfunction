scoreboard players add player Fight 1

execute if score player Fight matches 1 run summon minecraft:armor_stand -178.0 -48.0 77.5 {ArmorItems:[{},{},{},{id:"minecraft:porkchop",Count:1b}],NoGravity:1,Invulnerable:1,Invisible:1,Tags:["train_model","fight_model"],Rotation:[90.0f,0.0f]}

execute if score player Fight matches 20..60 as @e[tag=train_model] at @s run tp @s ~ ~ ~0.2

execute if score player Fight matches 80.. run tag @s add enemy_turn
execute if score player Fight matches 80.. run scoreboard players reset player Fight