scoreboard players add player Fight 1

execute if score player Fight matches 1 run gamerule doTileDrops false

execute if score player Fight matches 20 run setblock -178 -48 85 minecraft:cauldron
execute if score player Fight matches 20 run fill -178 -48 85 -178 -48 85 minecraft:air destroy
execute if score player Fight matches 20 run setblock -178 -48 85 minecraft:cauldron

execute if score player Fight matches 30 run setblock -178 -47 85 minecraft:oak_trapdoor
execute if score player Fight matches 30 run fill -178 -47 87 -178 -47 85 minecraft:air destroy
execute if score player Fight matches 30 run setblock -178 -47 85 minecraft:oak_trapdoor[facing=south,half=bottom,open=false,powered=false,waterlogged=false]

execute if score player Fight matches 40 run setblock -178 -47 85 air
execute if score player Fight matches 40 run setblock -178 -47 85 minecraft:oak_trapdoor[facing=south,half=bottom,open=true,powered=false,waterlogged=false]
execute if score player Fight matches 40 run playsound minecraft:block.wooden_trapdoor.open master @s ~ ~ ~ 5 1

execute if score player Fight matches 50 run setblock -178 -48 85 minecraft:air
execute if score player Fight matches 50 run setblock -178 -48 85 minecraft:water_cauldron[level=3]
execute if score player Fight matches 50 run playsound minecraft:item.bucket.empty master @s ~ ~ ~ 5 1

execute if score player Fight matches 70.. run tag @s add enemy_turn
execute if score player Fight matches 70.. run scoreboard players reset player Fight