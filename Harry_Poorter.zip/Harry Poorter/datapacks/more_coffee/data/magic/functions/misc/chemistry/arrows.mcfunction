summon minecraft:text_display -149 -46.2 68 {text:'{"text":"\\\\/","color":"yellow","bold":"true"}',Tags:["potions_CauldronText","potions_entity","potions_Cauldron"],billboard:"vertical",background:0b}
summon minecraft:text_display -149 -46 68 {text:'{"text":"|","color":"yellow","bold":"true"}',Tags:["potions_CauldronText","potions_entity","potions_Cauldron"],billboard:"vertical",background:0b}
summon minecraft:text_display -149 -45.8 68 {text:'{"text":"|","color":"yellow","bold":"true"}',Tags:["potions_CauldronText","potions_entity","potions_Cauldron"],billboard:"vertical",background:0b}

tag @s add potions_arrows