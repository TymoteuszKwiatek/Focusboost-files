# push no gravity spell
execute if entity @s[nbt={SelectedItem:{tag:{Rod:1}}}] anchored eyes run function magic:misc/spells/push_spell
execute if entity @s[nbt={SelectedItem:{tag:{Rod:2}}}] anchored eyes run function magic:misc/spells/lock_spell
execute if entity @s[nbt={SelectedItem:{tag:{Rod:3}}}] anchored eyes run function magic:misc/spells/tp_spell


# reset
scoreboard players reset @s SpellClick