execute if score enemy Fight matches 1 unless score att Fight matches 2 run function magic:misc/fight/enemy/1
execute if score enemy Fight matches 1 if score att Fight matches 2 run function magic:misc/fight/enemy/1d

execute if score enemy Fight matches 2 unless score att Fight matches 3 run function magic:misc/fight/enemy/2
execute if score enemy Fight matches 2 if score att Fight matches 3 run function magic:misc/fight/enemy/2d

execute if score enemy Fight matches 3 unless score att Fight matches 4 run function magic:misc/fight/enemy/3
execute if score enemy Fight matches 3 if score att Fight matches 4 run function magic:misc/fight/enemy/3d

execute if score enemy Fight matches 4 unless score att Fight matches 5 run function magic:misc/fight/enemy/4
execute if score enemy Fight matches 4 if score att Fight matches 5 run function magic:misc/fight/enemy/4d

execute if score enemy Fight matches 5 unless score att Fight matches 1 run function magic:misc/fight/enemy/5
execute if score enemy Fight matches 5 if score att Fight matches 1 run function magic:misc/fight/enemy/5d