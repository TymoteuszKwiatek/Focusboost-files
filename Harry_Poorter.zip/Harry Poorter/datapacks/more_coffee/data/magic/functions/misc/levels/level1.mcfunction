# init
scoreboard players set .boxEnd levels 1
kill @e[tag=levels_entity,tag=!puzzle1]
summon minecraft:armor_stand -105 -40 153 {Tags:["Puzzle_Box","levels_entity"],Invulnerable:1b,DisabledSlots:4144959,Marker:0b,Invisible:1b,ArmorItems:[{},{},{},{id:"minecraft:cake",Count:1b}]}

# blocks
setblock -105 -41 153 minecraft:brown_glazed_terracotta
setblock -105 -44 153 minecraft:stripped_mangrove_log[axis=y]

# reset
scoreboard players set .loaded levels 1