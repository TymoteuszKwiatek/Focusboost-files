scoreboard players add enemytim Fight 1

execute if score enemytim Fight matches 20..80 run particle splash -178.0 -46.0 95.0 0.5 0.5 0.5 0.5 5 force @a

execute if score enemytim Fight matches 20 run tellraw @s [{"text":"<Uczniowie Hudgeward>","color":"red"},{"color":"gray","text":" Bądź świadkiem naszej ogromnej siły!"}]
execute if score enemytim Fight matches 60 run tellraw @s [{"text":"<Uczniowie Hudgeward>","color":"red"},{"color":"gray","text":" LODOWAAA...."}]
execute if score enemytim Fight matches 80 run tellraw @s [{"text":"<Uczniowie Hudgeward>","color":"red"},{"color":"gray","text":" WŁÓCZNIAAAA!!!!"}]

execute if score enemytim Fight matches 80 run playsound minecraft:entity.illusioner.cast_spell master @s ~ ~ ~ 5 1
execute if score enemytim Fight matches 80 run summon minecraft:armor_stand -179 -48 94 {NoGravity:1,Invulnerable:1,Invisible:1,Tags:["ice_spear","fight_model"]}

execute if score enemytim Fight matches 80..91 as @e[tag=ice_spear] at @s run tp @s ~ ~ ~-1
execute if score enemytim Fight matches 80..90 as @e[tag=ice_spear] at @s run setblock ~ ~1 ~ minecraft:packed_ice
execute if score enemytim Fight matches 80..91 as @e[tag=ice_spear] at @s run fill ~ ~1 ~1 ~ ~1 ~1 minecraft:air destroy

execute if score enemytim Fight matches 91 run particle minecraft:explosion_emitter -178.04 -46.89 83.65 0 0 0 0.1 3 force @a
execute if score enemytim Fight matches 91 run playsound minecraft:entity.generic.explode master @s ~ ~ ~ 5 1
execute if score enemytim Fight matches 91 run kill @e[tag=ice_spear]

execute if score enemytim Fight matches 120.. run function magic:misc/fight/player/reset
execute if score enemytim Fight matches 120.. run tag @s remove enemy_turn
execute if score enemytim Fight matches 120.. run tag @s add hurt
execute if score enemytim Fight matches 120.. run scoreboard players reset enemytim Fight