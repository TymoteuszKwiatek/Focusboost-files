execute on target at @s run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 10000 2
execute on target run kill @s
execute on attacker at @s run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 10000 2
execute on attacker run kill @s