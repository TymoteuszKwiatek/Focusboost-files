execute on attacker as @s[nbt={SelectedItem:{id:"minecraft:mutton",Count:1b}}] run scoreboard players add .items potions 1
execute on attacker as @s[nbt={SelectedItem:{id:"minecraft:cooked_mutton",Count:1b}}] run scoreboard players add .items potions 1
execute on attacker as @s[nbt={SelectedItem:{id:"minecraft:chicken",Count:1b}}] run scoreboard players add .items potions 1

execute on target as @s[nbt={SelectedItem:{id:"minecraft:mutton",Count:1b}}] run scoreboard players add .items potions 1
execute on target as @s[nbt={SelectedItem:{id:"minecraft:cooked_mutton",Count:1b}}] run scoreboard players add .items potions 1
execute on target as @s[nbt={SelectedItem:{id:"minecraft:chicken",Count:1b}}] run scoreboard players add .items potions 1

execute on attacker if data entity @s SelectedItem run particle minecraft:splash -149 -47 68 0.1 0.1 0.1 0 20 force @s
execute on target if data entity @s SelectedItem run particle minecraft:splash -149 -47 68 0.1 0.1 0.1 0 20 force @s

execute on attacker if data entity @s SelectedItem run playsound minecraft:entity.generic.splash master @a ~ ~ ~ 1 1.1
execute on target if data entity @s SelectedItem run playsound minecraft:entity.generic.splash master @a ~ ~ ~ 1 1.1
execute on target if data entity @s SelectedItem run item replace entity @s weapon.mainhand with air
execute on attacker if data entity @s SelectedItem run item replace entity @s weapon.mainhand with air