# init
scoreboard players set .boxEnd levels 1
kill @e[tag=levels_entity,tag=!puzzle1]
summon minecraft:armor_stand -104 -40 151 {Tags:["Puzzle_Box","levels_entity"],Invulnerable:1b,DisabledSlots:4144959,Marker:0b,Invisible:1b,ArmorItems:[{},{},{},{id:"minecraft:cake",Count:1b}]}

summon minecraft:armor_stand -103 -40 150 {Tags:["Puzzle_Box","levels_entity"],Invulnerable:1b,DisabledSlots:4144959,Marker:0b,Invisible:1b,ArmorItems:[{},{},{},{id:"minecraft:cake",Count:1b}]}

# blocks
setblock -105 -44 151 minecraft:stripped_mangrove_log[axis=y]
setblock -107 -40 151 minecraft:smooth_stone
fill -102 -41 152 -104 -41 150 smooth_stone
setblock -103 -40 152 minecraft:smooth_stone


# reset
scoreboard players set .loaded levels 1