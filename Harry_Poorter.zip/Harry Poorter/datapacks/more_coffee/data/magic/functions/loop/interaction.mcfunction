# start spawn interaction
execute as @s[tag=Spawn_StartInteraction] if data entity @s interaction run function magic:misc/start_lobby/start
execute as @s[tag=Spawn_StartInteraction] if data entity @s interaction run data remove entity @s interaction

execute as @s[tag=Spawn_StartInteraction] if data entity @s attack run function magic:misc/start_lobby/start
execute as @s[tag=Spawn_StartInteraction] if data entity @s attack run data remove entity @s attack

# quit spawn interaction
execute as @s[tag=Spawn_QuitInteraction] if data entity @s interaction run function magic:misc/start_lobby/quit
execute as @s[tag=Spawn_QuitInteraction] if data entity @s interaction run data remove entity @s interaction

execute as @s[tag=Spawn_QuitInteraction] if data entity @s attack run function magic:misc/start_lobby/quit
execute as @s[tag=Spawn_QuitInteraction] if data entity @s attack run data remove entity @s attack

# info spawn interaction
execute as @s[tag=Spawn_InfoInteraction] if data entity @s interaction run function magic:misc/start_lobby/info
execute as @s[tag=Spawn_InfoInteraction] if data entity @s interaction run data remove entity @s interaction

execute as @s[tag=Spawn_InfoInteraction] if data entity @s attack run function magic:misc/start_lobby/info
execute as @s[tag=Spawn_InfoInteraction] if data entity @s attack run data remove entity @s attack