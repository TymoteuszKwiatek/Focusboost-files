# Spawn slime move
execute as @s[tag=Spawn_StartGlow,tag=Spawn_StartGlowUp] at @s positioned ~ -54.0 ~ unless entity @s[distance=..0.25] at @s run tp @s ~ ~0.01 ~
execute as @s[tag=Spawn_StartGlow,tag=Spawn_StartGlowUp] at @s positioned ~ -54.0 ~ if entity @s[distance=..0.25] at @s run tag @s add Spawn_StartGlowDown
execute as @s[tag=Spawn_StartGlow,tag=Spawn_StartGlowUp] at @s positioned ~ -54.0 ~ if entity @s[distance=..0.25] at @s run tag @s remove Spawn_StartGlowUp

execute as @e[tag=Spawn_StartGlow,tag=Spawn_StartGlowDown] at @s positioned ~ -55.0 ~ unless entity @s[distance=..0.25] at @s run tp @s ~ ~-0.01 ~
execute as @s[tag=Spawn_StartGlow,tag=Spawn_StartGlowDown] at @s positioned ~ -55.0 ~ if entity @s[distance=..0.25] at @s run tag @s add Spawn_StartGlowUp
execute as @s[tag=Spawn_StartGlow,tag=Spawn_StartGlowDown] at @s positioned ~ -55.0 ~ if entity @s[distance=..0.25] at @s run tag @s remove Spawn_StartGlowDown
# spawn slime rotation
execute as @s[tag=Spawn_StartGlow] at @s run tp @s ~ ~ ~ ~5 ~
# spawn start slime color glow
execute as @s[tag=Spawn_StartGlow] at @s positioned ~ -56 ~ if entity @a[distance=..4,limit=1] run effect give @s minecraft:glowing infinite 1 true
execute as @s[tag=Spawn_StartGlow] at @s positioned ~ -56 ~ unless entity @a[distance=..4,limit=1] run effect clear @s minecraft:glowing