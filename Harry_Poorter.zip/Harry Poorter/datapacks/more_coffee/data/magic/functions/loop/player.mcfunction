execute if entity @s[tag=intro] run function magic:text/intro
execute if entity @s[tag=potions] run function magic:text/potions
execute if entity @s[tag=potions2] run function magic:text/potions2
execute if entity @s[tag=spells] run function magic:text/spells
execute if entity @s[tag=potions_gameplay] run function magic:misc/chemistry/main
execute if entity @s[tag=spells_gameplay] run function magic:misc/spells/main
execute if entity @s[tag=spells_gameplay] run function magic:misc/spells/lesson/lesson
execute if entity @s[tag=levels_gameplay] run function magic:misc/levels/main
execute if entity @s[tag=levels_gameplay] run function magic:misc/spells/main
execute if entity @s[tag=ending_game] run function magic:text/ending

# levels and advancements
xp set @s 0 levels
xp set @s 0 points
advancement revoke @s everything
effect give @s minecraft:saturation infinite 255 true

# cauldorn arrows
execute if predicate magic:cauldron_look if entity @s[nbt={SelectedItem:{tag:{potion_item:1b}}},tag=!potions_arrows] run function magic:misc/chemistry/arrows
execute if entity @s[tag=potions_arrows] unless entity @s[nbt={SelectedItem:{tag:{potion_item:1b}}}] run function magic:misc/chemistry/kill_arrows
execute if entity @s[tag=potions_arrows] unless predicate magic:cauldron_look run function magic:misc/chemistry/kill_arrows

# fight
execute if entity @s[x=-151,y=-48,z=85,dx=3,dy=5,dz=1,tag=potion_end] run tag @s add corridor_fight
execute if entity @s[tag=corridor_fight] run function magic:text/corridor_fight

# spells
execute if entity @s[scores={SpellClick=1..}] run function magic:misc/spells/handler
execute positioned -133.0 -48.0 111.0 as @a[tag=!spells_detected,distance=..1] run tag @s add spells
execute positioned -133.0 -48.0 111.0 as @a[tag=!spells_detected,distance=..1] run tag @s add spells_detected

# lacrimosa
execute if entity @s[tag=lacrimosa] run function magic:text/lacrimosa

# fight
execute if entity @s[tag=fight_system] run function magic:misc/fight/main