# spawn text color glow idk
execute as @s[tag=Spawn_StartText] at @s positioned ~ -56 ~ if entity @a[distance=..4,limit=1] run data merge entity @s {text:'{"text":"- START -","color":"#f7cd4f","bold":"true"}'}
execute as @s[tag=Spawn_StartText] at @s positioned ~ -56 ~ unless entity @a[distance=..4,limit=1] run data merge entity @s {text:'{"text":"- START -","color":"#FCBA03","bold":"true"}'}

# quit
execute as @s[tag=Spawn_QuitText] at @s positioned ~ -56 ~ if entity @a[distance=..4,limit=1] run data merge entity @s {text:'{"text":"- WYJŚCIE -","color":"#f7cd4f","bold":"true"}'}
execute as @s[tag=Spawn_QuitText] at @s positioned ~ -56 ~ unless entity @a[distance=..4,limit=1] run data merge entity @s {text:'{"text":"- WYJŚCIE -","color":"#FCBA03","bold":"true"}'}

# informations
execute as @s[tag=Spawn_InfoText] at @s positioned ~ -56 ~ if entity @a[distance=..4,limit=1] run data merge entity @s {text:'{"text":"- INFO -","color":"#f7cd4f","bold":"true"}'}
execute as @s[tag=Spawn_InfoText] at @s positioned ~ -56 ~ unless entity @a[distance=..4,limit=1] run data merge entity @s {text:'{"text":"- INFO -","color":"#FCBA03","bold":"true"}'}

# authors
execute as @s[tag=Spawn_AuthorsText] at @s positioned ~ -56 ~ if entity @a[distance=..4,limit=1] run data merge entity @s {text:'{"text":"- AUTORZY -","color":"#f7cd4f","bold":"true"}'}
execute as @s[tag=Spawn_AuthorsText] at @s positioned ~ -56 ~ unless entity @a[distance=..4,limit=1] run data merge entity @s {text:'{"text":"- AUTORZY -","color":"#FCBA03","bold":"true"}'}
# note in authors
execute as @s[tag=Spawn_AuthorsTexttNote] at @s positioned ~ -56 ~ if entity @a[distance=..4,limit=1] run data merge entity @s {text_opacity:0b}
execute as @s[tag=Spawn_AuthorsTexttNote] at @s positioned ~ -56 ~ unless entity @a[distance=..4,limit=1] run data merge entity @s {text_opacity:4b}