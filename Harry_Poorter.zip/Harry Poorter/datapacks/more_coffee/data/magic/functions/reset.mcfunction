tag @a remove intro
tag @a remove potions
tag @a remove potions2
tag @a remove potions_gameplay
tag @a remove potion_end
tag @a remove corridor_fight
tag @a remove spells
tag @a remove spells_gameplay
tag @a remove levels_gameplay
tag @a remove speaker2
tag @a remove biblia
tag @a remove spell_detected

scoreboard players reset intro Text
scoreboard players reset potions Text
scoreboard players reset potions2 Text
scoreboard players reset corridor_fight Text
scoreboard players reset spells Text
scoreboard players reset .time spells
scoreboard players set .action spells 0
scoreboard players set .level levels 0
scoreboard players set .loop levels 0
scoreboard players set .loaded levels 0

kill @e[tag=ending_entity]
kill @e[tag=potions_entity]
kill @e[tag=potions_arrows]
kill @e[tag=spells_entity]
kill @e[tag=fight_model]
kill @e[type=item]

fill -140 -48 60 -140 -46 61 minecraft:iron_bars
fill -128 -44 104 -128 -46 104 oak_planks
fill -129 -45 104 -127 -45 104 oak_planks
fill -129 -48 96 -127 -48 95 air

setblock -128 -44 104 oak_stairs
setblock -147 -47 57 minecraft:oak_planks
setblock -149 -48 68 minecraft:air