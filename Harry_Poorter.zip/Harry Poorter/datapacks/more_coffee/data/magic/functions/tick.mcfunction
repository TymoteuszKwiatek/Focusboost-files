function magic:loop/world
execute as @a at @s run function magic:loop/player
execute as @e[type=armor_stand] at @s run function magic:loop/am
execute as @e[type=slime] at @s run function magic:loop/slime
execute as @e[type=text_display] at @s run function magic:loop/text_display
execute as @e[type=item_display] at @s run function magic:loop/item_display
execute as @e[type=interaction] at @s run function magic:loop/interaction