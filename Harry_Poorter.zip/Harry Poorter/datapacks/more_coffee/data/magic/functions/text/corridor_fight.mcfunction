scoreboard players add corridor_fight Text 1

execute if score corridor_fight Text matches 1 run tag @s remove potion_end
execute if score corridor_fight Text matches 1 run function magic:text/misc/fight_cam

execute if score corridor_fight Text matches 10 run gamemode spectator @s
execute if score corridor_fight Text matches 10..150 run spectate @e[tag=fight_cam1,limit=1] @s
execute if score corridor_fight Text matches 151..200 run spectate @e[tag=fight_cam2,limit=1] @s
execute if score corridor_fight Text matches 201..250 run spectate @e[tag=fight_cam3,limit=1] @s
execute if score corridor_fight Text matches 251..280 run spectate @e[tag=fight_cam2,limit=1] @s
execute if score corridor_fight Text matches 281..300 run spectate @e[tag=fight_cam3,limit=1] @s
execute if score corridor_fight Text matches 301..320 run spectate @e[tag=fight_cam2,limit=1] @s
execute if score corridor_fight Text matches 321..340 run spectate @e[tag=fight_cam3,limit=1] @s
execute if score corridor_fight Text matches 341..360 run spectate @e[tag=fight_cam2,limit=1] @s
execute if score corridor_fight Text matches 361..450 run spectate @e[tag=fight_cam3,limit=1] @s
execute if score corridor_fight Text matches 451..475 run spectate @e[tag=fight_cam4,limit=1] @s

execute if score corridor_fight Text matches 475.. run tp @s @e[tag=fight_cam4,limit=1]

execute if score corridor_fight Text matches 1 run title @s times 10 20 10
execute if score corridor_fight Text matches 1 run title @s title {"text":"\uE000"}

execute if score corridor_fight Text matches 60 as @e[tag=fight_cam1] at @s run tp @s ~ ~ ~ -150 ~
execute if score corridor_fight Text matches 60 run playsound minecraft:meme1 master @s ~ ~ ~ 5 1

execute if score corridor_fight Text matches 60 run data merge entity @e[tag=fight_player,limit=1] {start_interpolation:-1,interpolation_duration:20,transformation:{translation:[0.0f,0.0f,-6.0f]}}

execute if score corridor_fight Text matches 90 as @e[tag=fight_cam1] at @s run tp @s ~ ~ ~ -30 ~
execute if score corridor_fight Text matches 90 run playsound minecraft:meme1 master @s ~ ~ ~ 5 1

execute if score corridor_fight Text matches 90 as @e[tag=fight_enemy] run data merge entity @s {start_interpolation:-1,interpolation_duration:20,transformation:{translation:[-6.5f,0.0f,0.0f]}}
execute if score corridor_fight Text matches 110 as @e[tag=fight_enemy] run data merge entity @s {start_interpolation:-1,interpolation_duration:20,transformation:{translation:[-6.5f,0.0f,-6.0f]}}

execute if score corridor_fight Text matches 150 run item replace entity @s armor.head with minecraft:carved_pumpkin{Enchantments:[{id:"minecraft:binding_curse",lvl:1s}]}

execute if score corridor_fight Text matches 150 run tellraw @s [{"text":"<Harry Poorter>","color":"aqua"},{"color":"gray","text":" O nie..."}]
execute if score corridor_fight Text matches 150 run playsound minecraft:meme1 master @s ~ ~ ~ 5 1

execute if score corridor_fight Text matches 200 run tellraw @s [{"text":"<Kolesie>","color":"red"},{"color":"gray","text":" O tak..."}]
execute if score corridor_fight Text matches 200 run playsound minecraft:meme1 master @s ~ ~ ~ 5 1

execute if score corridor_fight Text matches 249 as @e[tag=fight_cam2] at @s run tp @s ~ ~ ~-1
execute if score corridor_fight Text matches 250 run tellraw @s [{"text":"<Harry Poorter>","color":"aqua"},{"color":"gray","text":" Wy jesteście..."}]
execute if score corridor_fight Text matches 250 run playsound minecraft:meme1 master @s ~ ~ ~ 5 1

execute if score corridor_fight Text matches 279 as @e[tag=fight_cam3] at @s run tp @s ~ ~ ~1
execute if score corridor_fight Text matches 280 run tellraw @s [{"text":"<Kolesie>","color":"red"},{"color":"gray","text":" Tak"}]
execute if score corridor_fight Text matches 280 run playsound minecraft:meme1 master @s ~ ~ ~ 5 1

execute if score corridor_fight Text matches 299 as @e[tag=fight_cam2] at @s run tp @s ~ ~ ~-1
execute if score corridor_fight Text matches 300 run tellraw @s [{"text":"<Harry Poorter>","color":"aqua"},{"color":"gray","text":" STUDENCI Z HUDGEWARD!"}]
execute if score corridor_fight Text matches 300 run playsound minecraft:meme1 master @s ~ ~ ~ 5 1

execute if score corridor_fight Text matches 319 as @e[tag=fight_cam3] at @s run tp @s ~ ~ ~1
execute if score corridor_fight Text matches 320 run tellraw @s [{"text":"<Uczniowie Hudgeward>","color":"red"},{"color":"gray","text":" TAK!!!"}]
execute if score corridor_fight Text matches 320 run playsound minecraft:meme1 master @s ~ ~ ~ 5 1

execute if score corridor_fight Text matches 339 run data merge entity @e[tag=fight_player,limit=1] {transformation:{left_rotation:{axis:[0.0f,0.0f,1.0f],angle:0.785},scale:[2.0f,1.0f,1.0f]}}
execute if score corridor_fight Text matches 339 run data merge entity @e[tag=fight_player2,limit=1] {transformation:{scale:[2.0f,1.0f,1.0f]}}
execute if score corridor_fight Text matches 340 run tellraw @s [{"text":"<Harry Poorter>","color":"aqua"},{"color":"gray","text":" Mam przeje**ne..."}]
execute if score corridor_fight Text matches 340 run playsound minecraft:meme1 master @s ~ ~ ~ 5 1

execute if score corridor_fight Text matches 359 as @e[tag=fight_cam3] at @s run tp @s ~ ~ ~1
execute if score corridor_fight Text matches 360 run tellraw @s [{"text":"<Uczniowie Hudgeward>","color":"red"},{"color":"gray","text":" tak..."}]
execute if score corridor_fight Text matches 360 run playsound minecraft:meme1 master @s ~ ~ ~ 5 1

execute if score corridor_fight Text matches 220 run tag @s add lacrimosa
execute if score corridor_fight Text matches 220 run playsound minecraft:lacrimosa master @s ~ ~ ~ 5 1

execute if score corridor_fight Text matches 380..425 as @e[tag=fight_cam3] at @s run tp @s ^ ^ ^-0.25 ~-2 ~1
execute if score corridor_fight Text matches 380 run tellraw @s [{"text":"<Uczniowie Hudgeward>","color":"red"},{"color":"gray","text":" a teraz... wyciągnij swą ruszczke..."}]
execute if score corridor_fight Text matches 425 run tellraw @s [{"text":"<Uczniowie Hudgeward>","color":"red"},{"color":"gray","text":" musimy trochę poszpanować ;)"}]

execute if score corridor_fight Text matches 400 run data merge entity @e[tag=fight_player,limit=1] {start_interpolation:-1,interpolation_duration:25,transformation:{translation:[0.0f,0.0f,-9.0f],left_rotation:{axis:[0.0f,0.0f,1.0f],angle:0.0}}}
execute if score corridor_fight Text matches 400 as @e[tag=fight_enemy] run data merge entity @s {start_interpolation:-1,interpolation_duration:25,transformation:{translation:[-6.5f,0.0f,-9.0f]}}

execute if score corridor_fight Text matches 425 run item replace entity @s armor.head with minecraft:air
execute if score corridor_fight Text matches 425 as @e[tag=fight_cam3] at @s run tp @s -155 -44 96.0

execute if score corridor_fight Text matches 475 run gamemode adventure @s

execute if score corridor_fight Text matches 500.. run tag @s remove corridor_fight
execute if score corridor_fight Text matches 500.. run function magic:misc/fight/init
execute if score corridor_fight Text matches 500.. run scoreboard players reset corridor_fight Text