summon armor_stand -154.75 -42.8 95.5 {NoGravity:1,Invisible:1,Invulnerable:1,DisabledSlots:4144959,Tags:["fight_cam","fight_cam1"],Rotation:[-90.0f,45.0f],Silent:1}
summon armor_stand -149.0 -48.0 91.0 {NoGravity:1,Invisible:1,Invulnerable:1,DisabledSlots:4144959,Tags:["fight_cam","fight_cam2"],Rotation:[180.0f,0.0f],Silent:1}
summon armor_stand -149.0 -48.0 101.0 {NoGravity:1,Invisible:1,Invulnerable:1,DisabledSlots:4144959,Tags:["fight_cam","fight_cam3"],Rotation:[0.0f,0.0f],Silent:1}
summon armor_stand -184 -44 89.0 {NoGravity:1,Invisible:1,Invulnerable:1,DisabledSlots:4144959,Tags:["fight_cam","fight_cam4"],Rotation:[-92.0f,38.0f],Silent:1}


summon minecraft:item_display -149.0 -47.5 81.5 {NoGravity:1,Invulnerable:1,item:{id:"minecraft:beef",Count:1b},Tags:["fight_player","fight_model"],Rotation:[180f,0f]}
summon minecraft:item_display -143.5 -47.5 111.0 {NoGravity:1,Invulnerable:1,item:{id:"minecraft:cod",Count:1b},Tags:["fight_enemy","fight_model","fight_enemy1"],Rotation:[0f,0f]}
summon minecraft:item_display -142.5 -47.5 111.0 {NoGravity:1,Invulnerable:1,item:{id:"minecraft:cod",Count:1b},Tags:["fight_enemy","fight_model","fight_enemy2"],Rotation:[0f,0f]}
summon minecraft:item_display -141.5 -47.5 111.0 {NoGravity:1,Invulnerable:1,item:{id:"minecraft:cod",Count:1b},Tags:["fight_enemy","fight_model","fight_enemy3"],Rotation:[0f,0f]}

summon minecraft:item_display -179.0 -47.5 95.0 {NoGravity:1,Invulnerable:1,item:{id:"minecraft:cod",Count:1b},Tags:["fight_enemy2","fight_model","fight_enemy1"],Rotation:[0f,0f]}
summon minecraft:item_display -178.0 -47.5 95.0 {NoGravity:1,Invulnerable:1,item:{id:"minecraft:cod",Count:1b},Tags:["fight_enemy2","fight_model","fight_enemy1"],Rotation:[0f,0f]}
summon minecraft:item_display -177.0 -47.5 95.0 {NoGravity:1,Invulnerable:1,item:{id:"minecraft:cod",Count:1b},Tags:["fight_enemy2","fight_model","fight_enemy1"],Rotation:[0f,0f]}

summon minecraft:item_display -178.0 -47.5 83.5 {NoGravity:1,Invulnerable:1,item:{id:"minecraft:beef",Count:1b},Tags:["fight_player2","fight_model"],Rotation:[180f,0f]}