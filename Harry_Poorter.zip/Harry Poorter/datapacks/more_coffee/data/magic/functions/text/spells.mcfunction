scoreboard players add spells Text 1

#init
execute if score spells Text matches 1 run function magic:text/misc/spells_cam
# fade
execute if score spells Text matches 1 run title @s times 10 20 10
execute if score spells Text matches 1 run title @s title {"text":"\uE000"}

execute if score spells Text matches 1 run item replace entity @s armor.head with minecraft:carved_pumpkin{Enchantments:[{id:"minecraft:binding_curse",lvl:1s}]}
execute if score spells Text matches 1 run gamemode spectator @s
execute if score spells Text matches 2 run spectate @e[tag=spells_cam,limit=1] @s

# doors
execute if score spells Text matches 20 run setblock -154 -42 118 minecraft:redstone_block
execute if score spells Text matches 20 run fill -136 -46 111 -136 -48 110 iron_bars
execute if score spells Text matches 20 run playsound minecraft:door master @a ~ ~ ~ 1 1

# blink
execute if score spells Text matches 80 run title @s times 5 5 5
execute if score spells Text matches 80 run title @s title {"text":"\uE000"}
execute if score spells Text matches 85 as @e[tag=spells_student] run data modify entity @s item.id set value beef
execute if score spells Text matches 85 as @e[tag=spells_teacher] run data modify entity @s item.id set value bread
execute if score spells Text matches 95 run playsound minecraft:meme1 master @s ~ ~ ~ 1 1

# teacher talk
execute if score spells Text matches 120 run tellraw @s [{"text":"<Nauczyciel>","color":"gold"},{"color":"gray","bold":"false","text":" Cześć wszyscy! To nasza pierwsza lekcja w "},{"text":"[","bold":"true","color":"white"},{"text":"Biedoszkoła","bold":"false","color":"gold"},{"text":"]","bold":"true","color":"white"},{"color":"gray","bold":"false","text":" i będę was uczyć zaklęć."}]
execute if score spells Text matches 120 run playsound minecraft:talk1 master @s ~ ~ ~ 1 0.8
execute if score spells Text matches 220 run tellraw @s [{"text":"<Nauczyciel>","color":"gold"},{"color":"gray","bold":"false","text":" Niech się przedstawie, jestem Bogden Niewysoki"}]
execute if score spells Text matches 220 run playsound minecraft:talk2 master @s ~ ~ ~ 1 0.8
execute if score spells Text matches 360 run tellraw @s [{"text":"<Bogden Niewysoki>","color":"gold"},{"color":"gray","bold":"false","text":" Dzisiaj pokażę wam parę podstawowych zaklęć, więc słuchajcie uważnie i nie przeszkadzajcie. Z R O Z U M I A N O?"}]
execute if score spells Text matches 360 run playsound minecraft:talk3 master @s ~ ~ ~ 1 0.8

execute if score spells Text matches 460 run tellraw @s [{"text":"<Bogden Niewysoki>","color":"gold"},{"color":"gray","bold":"false","text":" Dobra, więc zacznijmy od ULTR..."}]
execute if score spells Text matches 460 run playsound minecraft:talk1 master @s ~ ~ ~ 1 0.8
execute if score spells Text matches 560 run playsound minecraft:meme3 master @s -128 -47 118 1 1

# teacher throw a student
execute if score spells Text matches 570 run playsound minecraft:teleport master @s ~ ~ ~ 1 1
execute if score spells Text matches 570 as @e[tag=spells_teacher] run tp @s -128.27 -47 117.0 160 0
execute if score spells Text matches 570 run tellraw @s [{"text":"<Bogden Niewysoki>","color":"gold"},{"color":"gray","bold":"false","text":" MÓWIŁEM KURDE NIE PRZESZKADZAĆ MI!!!"}]
execute if score spells Text matches 570 run playsound minecraft:talk1 master @s -128 -47 118 1 0.8

execute if score spells Text matches 650 run tellraw @s [{"text":"<Miłosz Komórka>","color":"green"},{"color":"gray","bold":"false","text":" przepraszam nauczyci..."}]
execute if score spells Text matches 650 run playsound minecraft:talk2 master @s -128 -47 118 1 2

execute if score spells Text matches 700 run tellraw @s [{"text":"<Bogden Niewysoki>","color":"gold"},{"color":"gray","bold":"false","text":" NIE, nie wybaczę ci, leć w przestworza!"}]
execute if score spells Text matches 740 run playsound minecraft:meme4 master @s ~ ~ ~ 1 1
execute if score spells Text matches 700 run playsound minecraft:talk2 master @s -128 -47 118 1 0.8
# teacher animations
execute if score spells Text matches 760..780 as @e[tag=spells_teacher] at @s run tp @s ~ ~ ~ ~-6.5 ~1
execute if score spells Text matches 780..784 as @e[tag=spells_teacher] at @s run tp @s ~ ~ ~ ~ ~-4


# student through wall
execute if score spells Text matches 780 run summon pig -128 -47.5 119 {Tags:["spells_studentFly","spells_entity"]}
execute if score spells Text matches 781 run ride @e[tag=spells_studentTarget,limit=1] mount @e[tag=spells_studentFly,limit=1]
execute if score spells Text matches 785 run data merge entity @e[tag=spells_studentFly,limit=1] {Motion:[0.0d,0.55d,-4.0d]}

execute if score spells Text matches 790 as @e[tag=spells_cam] at @s run tp @s -125.89 -44.69 108.9 166 16

execute if score spells Text matches 790 run fill -128 -44 104 -128 -46 104 air destroy
execute if score spells Text matches 790 run fill -129 -45 104 -127 -45 104 air destroy
execute if score spells Text matches 830 run clone -134 -48 101 -132 -48 100 -129 -48 95
execute if score spells Text matches 830 run playsound minecraft:block.anvil.use master @s ~ ~ ~ 1 0.5
execute if score spells Text matches 810 as @e[tag=spells_cam] at @s run tp @s -123.869 -43.93 99.35 107.9 49.2

execute if score spells Text matches 830 run tellraw @s [{"text":"<Narrator>","color":"yellow"},{"color":"gray","text":" Welp... Już po nim..."}]
execute if score spells Text matches 830 at @s run playsound minecraft:entity.item.pickup master @s ~ ~ ~ 5 1

# back to classroom
execute if score spells Text matches 880 as @e[tag=spells_teacher] at @s run tp @s -122 -47 112 -90 0
execute if score spells Text matches 880 as @e[tag=spells_cam] at @s run tp @s -132 -48 106 -30 -1

# spells
execute if score spells Text matches 940 run tellraw @s [{"text":"<Bogden Niewysoki>","color":"gold"},{"color":"gray","bold":"false","text":" Ekhm.. na czym to ja... A, zacznijmy od ULTRA-BOSKI-UPADEK-WYSOKIEJ-JAKOŚCI-ZNISZCZENIA"}]
execute if score spells Text matches 940 run playsound minecraft:talk2 master @s -128 -47 118 1 0.8

execute if score spells Text matches 1040 run tellraw @s [{"text":"<Bogden Niewysoki>","color":"gold"},{"color":"gray","bold":"false","text":" Możesz znaleźć tę różdżkę gdzieś w MOJEJJJ KLASIE."}]
execute if score spells Text matches 1040 run playsound minecraft:talk3 master @s -128 -47 118 1 0.8

# fade
execute if score spells Text matches 1140 run title @s times 10 20 10
execute if score spells Text matches 1140 run title @s title {"text":"\uE000"}

execute if score spells Text matches 1170 run tag @s add spells_gameplay
execute if score spells Text matches 1170 run function magic:misc/spells/init
execute if score spells Text matches 1170 run tag @s remove spells
execute if score spells Text matches 1170 run item replace entity @s armor.head with air
execute if score spells Text matches 1170 run gamemode adventure @s
execute if score spells Text matches 1170 run scoreboard players reset spells Text




