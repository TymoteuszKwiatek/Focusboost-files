scoreboard players add ending Text 1

execute if score ending Text matches 5 positioned -69 -43 110 summon minecraft:item_display run data merge entity @s {NoGravity:1,Invulnerable:1,item:{id:"minecraft:bread",Count:1b},Tags:["ending_teacher1","ending_entity"],Rotation:[-90f,0f],transformation:{scale:[1.2f,3.5f,1.2f]}}
execute if score ending Text matches 5 positioned -69 -43 121 summon minecraft:item_display run data merge entity @s {item:{id:"minecraft:bread",Count:1b},Tags:["ending_teacher2","ending_entity"],transformation:{scale:[3.5,1.5,1.5]},Rotation:[-90f,0f]}
execute if score ending Text matches 5 positioned -68.3 -43 116.0 summon minecraft:item_display run data merge entity @s {item:{id:"minecraft:bread",Count:1b},Tags:["ending_teacher3","ending_entity"],Rotation:[-90f,0f]}

execute if score ending Text matches 5 run summon minecraft:iron_golem -79 -44 121 {Tags:["ending_golem","ending_entity"],NoAI:1b,Silent:1b,Fire:500s,Invulnerable:1b}

execute if score ending Text matches 25 run summon armor_stand -132 -48 106 {NoGravity:1,Invisible:1,Invulnerable:1,DisabledSlots:4144959,Tags:["ending_cam","ending_entity"],Rotation:[-30.0f,-1.0f],Silent:1}
execute if score ending Text matches 25 run item replace entity @s armor.head with minecraft:carved_pumpkin{Enchantments:[{id:"minecraft:binding_curse",lvl:1s}]}
execute if score ending Text matches 25.. run gamemode spectator @s
execute if score ending Text matches 25 as @e[tag=ending_cam] at @s run tp @s -85.6 -42.46 116.0 -90 7
execute if score ending Text matches 25.. run spectate @e[tag=ending_cam,limit=1] @s
execute if score ending Text matches 25 as @s at @s run playsound minecraft:music.dragon master @s ~ ~ ~ 1 1.4

# text
execute if score ending Text matches 40 run tellraw @s [{"text":"<Dyrektor>","color":"red"},{"color":"gray","bold":"false","text":" siema, uczniowie!"}]
execute if score ending Text matches 40 run playsound minecraft:talk1 master @s ~ ~ ~ 1 1

execute if score ending Text matches 100 run tellraw @s [{"text":"<Dyrektor>","color":"red"},{"color":"gray","bold":"false","text":" wasz rok szkolny dobiegł końca!"}]
execute if score ending Text matches 100 run playsound minecraft:talk2 master @s ~ ~ ~ 1 1

execute if score ending Text matches 200 run tellraw @s [{"text":"<Dyrektor>","color":"red"},{"color":"gray","bold":"false","text":" nie stać nas, by utrzymać was dłużej w tej szkole."}]
execute if score ending Text matches 200 run playsound minecraft:talk3 master @s ~ ~ ~ 1 1

execute if score ending Text matches 300 run tellraw @s [{"text":"<Dyrektor>","color":"red"},{"color":"gray","bold":"false","text":" więc to wasz koniec... lol..."}]
execute if score ending Text matches 300 run playsound minecraft:talk1 master @s ~ ~ ~ 1 1

execute if score ending Text matches 400 run tellraw @s [{"text":"<Dyrektor>","color":"red"},{"color":"gray","bold":"false","text":" Dziękuje za waszą... determinację i... cierpliwość idk."}]
execute if score ending Text matches 400 run playsound minecraft:talk2 master @s ~ ~ ~ 1 1

execute if score ending Text matches 500 run tellraw @s [{"text":"<Dyrektor>","color":"red"},{"color":"gray","bold":"false","text":" no więc wynocha"}]
execute if score ending Text matches 500 run playsound minecraft:talk3 master @s ~ ~ ~ 1 1

# cam
execute if score ending Text matches 200 as @e[tag=ending_cam] at @s run tp @s -66.3 -41.3 116.1 89.5 18.7
execute if score ending Text matches 400 as @e[tag=ending_cam] at @s run tp @s -77.2 -44.3 109.4 -43.6 -2.8

# fade
execute if score ending Text matches 500 run title @s times 110 50 0
execute if score ending Text matches 520 run title @s title {"text":"\uE000"}

execute if score ending Text matches 500 as @e[tag=ending_cam] at @s run tp @s -70.3 -43.57 116.0 -90 1.1
execute if score ending Text matches 520..630 as @e[tag=ending_cam] at @s run tp @s ~-0.1 ~ ~

execute if score ending Text matches 640 run title @s title {"text":""}
execute if score ending Text matches 639 run stopsound @s
execute if score ending Text matches 640 run playsound minecraft:meme1 master @s ~ ~ ~ 1 1
execute if score ending Text matches 640 as @e[tag=ending_cam] at @s run tp @s -70.3 -43.57 116.0 -90 1.1
execute if score ending Text matches 640 run tellraw @s [{"text":"<Dyrektor>","color":"red"},{"color":"gray","bold":"false","text":" WYPIER***LAĆĆĆĆ!!"}]
execute if score ending Text matches 640 run playsound minecraft:talk3 master @s ~ ~ ~ 1 1

execute if score ending Text matches 720 run title @s times 0 50 0
execute if score ending Text matches 720 run title @s title {"text":"\uE000"}
execute if score ending Text matches 740 run title @s title {"text":"DZIĘKUJEMY ZA GRĘ !","color":"green"}
execute if score ending Text matches 740 as @e[tag=ending_cam] at @s run tp @s -72 -34 115 0 0



