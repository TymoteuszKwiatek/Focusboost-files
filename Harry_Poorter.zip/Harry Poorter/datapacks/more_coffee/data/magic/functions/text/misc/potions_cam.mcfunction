kill @e[tag=potions_entity]
summon armor_stand -147 -48 62 {NoGravity:1,Invisible:1,Invulnerable:1,DisabledSlots:4144959,Tags:["potions_cam","potions_entity"],Rotation:[0.0f,0.0f],Silent:1}
summon marker -144 -47 65 {Tags:["potions_entity","potions_student1_pos"]}
summon marker -146 -47 65 {Tags:["potions_entity","potions_student2_pos"]}
summon marker -145 -47 62 {Tags:["potions_entity","potions_student3_pos"]}
summon marker -152 -47 59 {Tags:["potions_entity","potions_student4_pos"]}
summon marker -154 -47 59 {Tags:["potions_entity","potions_student5_pos"]}
summon marker -153 -47 62 {Tags:["potions_entity","potions_student6_pos"]}
summon marker -151 -47 62 {Tags:["potions_entity","potions_student7_pos"]}
summon marker -152 -47 65 {Tags:["potions_entity","potions_student8_pos"]}
summon marker -154 -47 65 {Tags:["potions_entity","potions_student9_pos"]}

summon minecraft:item_display -148.49 -47.51 68.44 {item:{id:"minecraft:melon_slice",Count:1b},Tags:["potions_entity","potions_CauldronModel"]}
setblock -149 -48 68 minecraft:iron_trapdoor[half=top]