kill @e[tag=spells_entity]
summon armor_stand -132 -48 106 {NoGravity:1,Invisible:1,Invulnerable:1,DisabledSlots:4144959,Tags:["spells_cam","spells_entity"],Rotation:[-30.0f,-1.0f],Silent:1}

# students
summon minecraft:item_display -130 -47.5 106 {NoGravity:1,Invulnerable:1,item:{id:"minecraft:air",Count:1b},Tags:["spells_student","spells_entity"],Rotation:[180f,0f]}
summon minecraft:item_display -128 -47 106 {NoGravity:1,Invulnerable:1,item:{id:"minecraft:air",Count:1b},Tags:["spells_student","spells_entity"],Rotation:[180f,0f]}
summon minecraft:item_display -126 -47.5 106 {NoGravity:1,Invulnerable:1,item:{id:"minecraft:air",Count:1b},Tags:["spells_student","spells_entity"],Rotation:[180f,0f]}
summon minecraft:item_display -124 -47.5 106 {NoGravity:1,Invulnerable:1,item:{id:"minecraft:air",Count:1b},Tags:["spells_student","spells_entity"],Rotation:[180f,0f]}

summon minecraft:item_display -132 -47 119 {NoGravity:1,Invulnerable:1,item:{id:"minecraft:air",Count:1b},Tags:["spells_student","spells_entity"],Rotation:[0f,0f]}
summon minecraft:item_display -130 -47 119 {NoGravity:1,Invulnerable:1,item:{id:"minecraft:air",Count:1b},Tags:["spells_student","spells_entity"],Rotation:[0f,0f]}
summon minecraft:item_display -128 -47 119 {NoGravity:1,Invulnerable:1,item:{id:"minecraft:air",Count:1b},Tags:["spells_student","spells_entity","spells_studentTarget"],Rotation:[0f,0f]}
summon minecraft:item_display -126 -47.5 119 {NoGravity:1,Invulnerable:1,item:{id:"minecraft:air",Count:1b},Tags:["spells_student","spells_entity"],Rotation:[0f,0f]}
summon minecraft:item_display -124 -47.5 119 {NoGravity:1,Invulnerable:1,item:{id:"minecraft:air",Count:1b},Tags:["spells_student","spells_entity"],Rotation:[0f,0f]}

# teacher
execute positioned -122 -47 112 summon minecraft:item_display run data merge entity @s {NoGravity:1,Invulnerable:1,item:{id:"minecraft:air",Count:1b},Tags:["spells_teacher","spells_entity"],Rotation:[-90f,0f],transformation:{scale:[1.2f,3.5f,1.2f]}}