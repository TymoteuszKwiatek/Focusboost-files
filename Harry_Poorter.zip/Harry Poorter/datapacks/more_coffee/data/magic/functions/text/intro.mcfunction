scoreboard players add intro Text 1
execute if score intro Text matches 1 run title @s times 5 10 5
execute if score intro Text matches 1 run title @s title {"text":"\uE000"}

execute if score intro Text matches 1 run item replace entity @s armor.head with minecraft:carved_pumpkin{Enchantments:[{id:"minecraft:binding_curse",lvl:1s}]}
execute if score intro Text matches 1 run gamemode spectator @s
execute if score intro Text matches 1 run function magic:text/misc/intro_cam

execute if score intro Text matches 1 run playsound minecraft:intro_music1 master @s ~ ~ ~
execute if score intro Text matches 1..89 run tp @s @e[tag=intro_cam1,limit=1]
execute if score intro Text matches 90..129 run tp @s -60.5 -57.0 69.5 -90 -5
execute if score intro Text matches 130..159 run tp @s -48.3 -57.0 49.5 -90 -15
execute if score intro Text matches 160..199 run tp @s -48.5 -57.0 49.5 90 0
execute if score intro Text matches 200..369 run tp @s @e[tag=intro_cam2,limit=1]
execute if score intro Text matches 370..499 run tp @s -78.5 -49.0 72.5 180 25
execute if score intro Text matches 500..889 run tp @s -74.0 -49.0 -5.0 115 -20
execute if score intro Text matches 890.. run tp @s @e[tag=intro_cam3,limit=1]

execute if score intro Text matches 1..89 as @e[tag=intro_cam1] at @s run tp @s ~0.2 ~ ~
execute if score intro Text matches 210..379 as @e[tag=intro_cam2] at @s run tp @s ^ ^ ^0.1
execute if score intro Text matches 890..940 as @e[tag=intro_cam3] at @s run tp @s ~ ~ ~0.2

execute if score intro Text matches 20 run tellraw @s [{"text":"<Narrator>","color":"yellow"},{"text":" [","bold":"true","color":"white"},{"text":"Hudgeward","bold":"false","color":"gold"},{"text":"]","bold":"true","color":"white"},{"color":"gray","bold":"false","text":" jest prestiżową szkołą dla czarowników..."}]
execute if score intro Text matches 21 at @s run playsound minecraft:entity.item.pickup master @s ~ ~ ~ 5 1

execute if score intro Text matches 90 run tellraw @s [{"text":"<Narrator>","color":"yellow"},{"color":"gray","text":" Oferująca świetnie wyposażone magiczne laboratoria!"}]
execute if score intro Text matches 91 at @s run playsound minecraft:entity.item.pickup master @s ~ ~ ~ 5 1

execute if score intro Text matches 130 run tellraw @s [{"text":"<Narrator>","color":"yellow"},{"color":"gray","text":" Kompetentnych nauczycieli!"}]
execute if score intro Text matches 131 at @s run playsound minecraft:entity.item.pickup master @s ~ ~ ~ 5 1
execute if score intro Text matches 135 run summon minecraft:villager -45.50 -56.50 49.50 {Xp:1,Tags:["g8teacher"],Silent:1b,Offers:{},NoAI: 1b,Rotation:[90.0f, 0.0f],VillagerData:{profession:"minecraft:librarian",level:1,type:"minecraft:plains"}}

execute if score intro Text matches 160 run tellraw @s [{"text":"<Narrator>","color":"yellow"},{"color":"gray","text":" I doskonałe środowisko do nauki!"}]
execute if score intro Text matches 161 at @s run playsound minecraft:entity.item.pickup master @s ~ ~ ~ 5 1

execute if score intro Text matches 200 run tellraw @s [{"text":"<Narrator>","color":"yellow"},{"color":"gray","text":" Po ukończeniu tej szkoły, studenci mają zapewioną świetlaną przyszłość."}]
execute if score intro Text matches 201 at @s run playsound minecraft:entity.item.pickup master @s ~ ~ ~ 5 1

execute if score intro Text matches 290 run tellraw @s [{"text":"<Narrator>","color":"yellow"},{"color":"gray","text":" Jest to możliwe tylko i wyłącznie, dlatego że uczniowie "},{"text":"[","bold":"true","color":"white"},{"text":"Hudgewardu","bold":"false","color":"gold"},{"text":"]","bold":"true","color":"white"},{"color":"gray","bold":"false","text":" mają jedną wspólną cechę:"}]
execute if score intro Text matches 291 at @s run playsound minecraft:entity.item.pickup master @s ~ ~ ~ 5 1

execute if score intro Text matches 370 run tellraw @s [{"text":"<Narrator>","color":"yellow"},{"color":"gray","text":" Są cholernie bogaci!"}]
execute if score intro Text matches 371 at @s run playsound minecraft:entity.item.pickup master @s ~ ~ ~ 5 1

execute if score intro Text matches 420 run tellraw @s [{"text":"<Narrator>","color":"yellow"},{"color":"gray","text":" Niestety to nie tutaj odbędzie się nasza historia."}]
execute if score intro Text matches 421 at @s run playsound minecraft:entity.item.pickup master @s ~ ~ ~ 5 1

execute if score intro Text matches 500 run stopsound @s master minecraft:intro_music1
execute if score intro Text matches 505 run playsound minecraft:intro_music2 master @s ~ ~ ~ 1 0.5

execute if score intro Text matches 500 run tellraw @s [{"text":"<Narrator>","color":"yellow"},{"color":"gray","text":" To jest "},{"text":"[","bold":"true","color":"white"},{"text":"Biedoszkoła","bold":"false","color":"gold"},{"text":"]","bold":"true","color":"white"},{"color":"gray","bold":"false","text":" magiczna szkoła dla tych, których nie stać na "},{"text":"[","bold":"true","color":"white"},{"text":"Hudgeward","bold":"false","color":"gold"},{"text":"]","bold":"true","color":"white"}]
execute if score intro Text matches 501 at @s run playsound minecraft:entity.item.pickup master @s ~ ~ ~ 5 1

execute if score intro Text matches 520 at @s run summon minecraft:lightning_bolt -108 -17 -4
execute if score intro Text matches 540 at @s run summon minecraft:lightning_bolt -108 -17 -4

execute if score intro Text matches 600 run tellraw @s [{"text":"<Narrator>","color":"yellow"},{"color":"gray","text":" Niestety nasz bohater nie był w stanie zapłacić nieziemskiego czesnego w "},{"text":"[","bold":"true","color":"white"},{"text":"Hudgewardzie","bold":"false","color":"gold"},{"text":"]","bold":"true","color":"white"},{"color":"gray","text":" i no.. skonczył tutaj."}]
execute if score intro Text matches 601 at @s run playsound minecraft:entity.item.pickup master @s ~ ~ ~ 5 1

execute if score intro Text matches 720 run tellraw @s [{"text":"<Narrator>","color":"yellow"},{"color":"gray","text":" Welp... Szkoda..."}]
execute if score intro Text matches 721 at @s run playsound minecraft:entity.item.pickup master @s ~ ~ ~ 5 1

execute if score intro Text matches 760 run tellraw @s [{"text":"<Narrator>","color":"yellow"},{"color":"gray","text":" Widzisz, "},{"text":"[","bold":"true","color":"white"},{"text":"Harry Poorter","bold":"false","color":"gold"},{"text":"]","bold":"true","color":"white"},{"color":"gray","text":" miał zjednoczyć świat czarodziejów."}]
execute if score intro Text matches 761 at @s run playsound minecraft:entity.item.pickup master @s ~ ~ ~ 5 1

execute if score intro Text matches 820 run tellraw @s [{"text":"<Narrator>","color":"yellow"},{"color":"gray","text":" Ale życie miało inne plany..."}]
execute if score intro Text matches 821 at @s run playsound minecraft:entity.item.pickup master @s ~ ~ ~ 5 1

execute if score intro Text matches 890 run tellraw @s [{"text":"<Narrator>","color":"yellow"},{"color":"gray","text":" Zobaczmy jak mu idzie na jego pierwszej lekcji "},{"text":"[","bold":"true","color":"white"},{"text":"Gotowania Mikstur","bold":"false","color":"gold"},{"text":"]","bold":"true","color":"white"},{"color":"gray","text":"."}]
execute if score intro Text matches 891 at @s run playsound minecraft:entity.item.pickup master @s ~ ~ ~ 5 1

execute if score intro Text matches 905 run gamerule doTileDrops false
execute if score intro Text matches 905 run fill -147 -47 57 -147 -47 57 minecraft:air destroy
execute if score intro Text matches 905 run gamerule doTileDrops true

execute if score intro Text matches 925 run setblock -147 -50 61 minecraft:redstone_wall_torch[facing=north,lit=true]
execute if score intro Text matches 940 run setblock -147 -50 61 minecraft:air
execute if score intro Text matches 940 run setblock -147 -47 57 minecraft:oak_planks

execute if score intro Text matches 950 run title @s times 10 20 10
execute if score intro Text matches 950 run title @s title {"text":"\uE000"}

execute if score intro Text matches 950 run tag @s remove intro
execute if score intro Text matches 950 run kill @e[tag=intro_cam]
execute if score intro Text matches 950 run kill @e[tag=g8teacher]
execute if score intro Text matches 950 run stopsound @s master minecraft:intro_music2
execute if score intro Text matches 950 run tag @s add potions
execute if score intro Text matches 950 run scoreboard players reset intro Text