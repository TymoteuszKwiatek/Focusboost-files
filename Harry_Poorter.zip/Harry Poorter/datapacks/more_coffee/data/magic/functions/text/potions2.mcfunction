scoreboard players add potions2 Text 1

# fade
execute if score potions2 Text matches 1 run title @s times 10 20 10
execute if score potions2 Text matches 1 run title @s title {"text":"\uE000"}

execute if score potions2 Text matches 1 run item replace entity @s armor.head with minecraft:carved_pumpkin{Enchantments:[{id:"minecraft:binding_curse",lvl:1s}]}
execute if score potions2 Text matches 1 run gamemode spectator @s
execute if score potions2 Text matches 1 as @e[tag=potions_cam] at @s run tp @s -147.52 -46.95 68.17 0 6 
execute if score potions2 Text matches 2.. run spectate @e[tag=potions_cam,limit=1] @s

# teacher tries potion
execute if score potions2 Text matches 40 run tellraw @s [{"text":"<Bogden Nieduży>","color":"gold"},{"color":"gray","bold":"false","text":" Już skończyłeś? Sprawdźmy to!"}]
execute if score potions2 Text matches 40 run playsound minecraft:talk1 master @s ~ ~ ~ 1 1

execute if score potions2 Text matches 140 run tellraw @s [{"text":"<Bogden Nieduży>","color":"gold"},{"color":"gray","bold":"false","text":" O w mordę! To serio pachnie dobrze!"}]
execute if score potions2 Text matches 140 run playsound minecraft:talk2 master @s ~ ~ ~ 1 1

execute if score potions2 Text matches 240 run tellraw @s [{"text":"<Bogden Nieduży>","color":"gold"},{"color":"gray","bold":"false","text":" Niesamowity kolor!"}]
execute if score potions2 Text matches 240 run playsound minecraft:talk3 master @s ~ ~ ~ 1 1

execute if score potions2 Text matches 280 run tellraw @s [{"text":"<Bogden Nieduży>","color":"gold"},{"color":"gray","bold":"false","text":" Przecudny zapach!"}]
execute if score potions2 Text matches 280 run playsound minecraft:talk1 master @s ~ ~ ~ 1 1

execute if score potions2 Text matches 320 run tellraw @s [{"text":"<Bogden Nieduży>","color":"gold"},{"color":"gray","bold":"false","text":" Ta konsystencja jest idealnaaa!!"}]
execute if score potions2 Text matches 320 run playsound minecraft:talk1 master @s ~ ~ ~ 1 1

execute if score potions2 Text matches 400 run tellraw @s [{"text":"<Bogden Nieduży>","color":"gold"},{"color":"gray","bold":"false","text":" I ten smak..."}]
execute if score potions2 Text matches 400 run playsound minecraft:talk1 master @s ~ ~ ~ 1 1

execute if score potions2 Text matches 460 run tellraw @s [{"text":"<Bogden Nieduży>","color":"gold"},{"color":"gray","bold":"false","text":" PRZEKOZAC..."}]
execute if score potions2 Text matches 460 run playsound minecraft:talk1 master @s ~ ~ ~ 1 1

# dancing teacher
execute if score potions2 Text matches 1 run fill -147 -48 70 -147 -47 70 barrier
execute if score potions2 Text matches 1 run fill -149 -47 70 -149 -48 70 barrier
execute if score potions2 Text matches 1 run setblock -148 -47 69 barrier
execute if score potions2 Text matches 1 run summon pig -148 -57.5 70 {Tags:["potions_teacherJump","potions_entity"],NoAI:1b,Silent:1b,Invulnerable:1b,NoGravity:1b}
execute if score potions2 Text matches 2 as @e[tag=potions_teacherJump] run effect give @s minecraft:invisibility infinite 1 true
execute if score potions2 Text matches 2 as @e[tag=potions_teacherJump] at @s run tp @s ~ ~10 ~
execute if score potions2 Text matches 2 run ride @e[tag=potions_teacher,limit=1] mount @e[tag=potions_teacherJump,limit=1]

# jump
execute if score potions2 Text matches 140..154 as @e[tag=potions_teacher] at @s run tp @s ~ ~ ~ ~24 ~
execute if score potions2 Text matches 140 as @e[tag=potions_teacherJump] run data merge entity @s {Motion:[0.0d,0.4d,0.0d],NoGravity:0b,NoAI:0b}
execute if score potions2 Text matches 155 as @e[tag=potions_teacherJump] run data merge entity @s {NoAI:1b}

execute if score potions2 Text matches 240..254 as @e[tag=potions_teacher] at @s run tp @s ~ ~ ~ ~-24 ~
execute if score potions2 Text matches 240 as @e[tag=potions_teacherJump] run data merge entity @s {Motion:[0.0d,0.4d,0.0d],NoGravity:0b,NoAI:0b}
execute if score potions2 Text matches 255 as @e[tag=potions_teacherJump] run data merge entity @s {NoAI:1b}

execute if score potions2 Text matches 280..294 as @e[tag=potions_teacher] at @s run tp @s ~ ~ ~ ~24 ~
execute if score potions2 Text matches 280 as @e[tag=potions_teacherJump] run data merge entity @s {Motion:[0.0d,0.4d,0.0d],NoGravity:0b,NoAI:0b}
execute if score potions2 Text matches 295 as @e[tag=potions_teacherJump] run data merge entity @s {NoAI:1b}

execute if score potions2 Text matches 320..334 as @e[tag=potions_teacher] at @s run tp @s ~ ~ ~ ~-24 ~
execute if score potions2 Text matches 320 as @e[tag=potions_teacherJump] run data merge entity @s {Motion:[0.0d,0.4d,0.0d],NoGravity:0b,NoAI:0b}
execute if score potions2 Text matches 335 as @e[tag=potions_teacherJump] run data merge entity @s {NoAI:1b}

execute if score potions2 Text matches 400..414 as @e[tag=potions_teacher] at @s run tp @s ~ ~ ~ ~24 ~
execute if score potions2 Text matches 400 as @e[tag=potions_teacherJump] run data merge entity @s {Motion:[0.0d,0.4d,0.0d],NoGravity:0b,NoAI:0b}
execute if score potions2 Text matches 415 as @e[tag=potions_teacherJump] run data merge entity @s {NoAI:1b}

execute if score potions2 Text matches 460..474 as @e[tag=potions_teacher] at @s run tp @s ~ ~ ~ ~-24 ~
execute if score potions2 Text matches 460 as @e[tag=potions_teacherJump] run data merge entity @s {Motion:[0.0d,0.4d,0.0d],NoGravity:0b,NoAI:0b}
execute if score potions2 Text matches 475 as @e[tag=potions_teacherJump] run data merge entity @s {NoAI:1b}

execute if score potions2 Text matches 480 run kill @e[tag=potions_teacher]
execute if score potions2 Text matches 480 run particle cloud -148 -47 70 0.5 1 -0.5 0.01 100 force @s
execute if score potions2 Text matches 480 run playsound minecraft:entity.generic.death master @s ~ ~ ~ 1 1
execute if score potions2 Text matches 490 run playsound minecraft:meme1 master @s ~ ~ ~ 1 1

execute if score potions2 Text matches 510 run playsound minecraft:dzwonek master @s -147.19 -47.24 66.33 10000 0.7

execute if score potions2 Text matches 530 run tp @e[tag=potions_cam] -142.5 -48.0 61.0 -90 0
execute if score potions2 Text matches 550 run playsound minecraft:kraty master @s ~ ~ ~ 5 1

execute if score potions2 Text matches 560 run fill -140 -48 60 -140 -48 61 minecraft:air
execute if score potions2 Text matches 570 run fill -140 -47 60 -140 -47 61 minecraft:air
execute if score potions2 Text matches 580 run fill -140 -46 60 -140 -46 61 minecraft:air

# fade
execute if score potions2 Text matches 600 run title @s times 20 20 20
execute if score potions2 Text matches 600 run title @s title {"text":"\uE000"}

execute if score potions2 Text matches 629 as @e[tag=potions_teacherJump] at @s run tp @s ~ ~-500 ~

execute if score potions2 Text matches 630 run fill -147 -47 69 -149 -48 70 air replace barrier
execute if score potions2 Text matches 630 run setblock -149 -48 68 minecraft:air
execute if score potions2 Text matches 630 run item replace entity @s armor.head with minecraft:air
execute if score potions2 Text matches 630 run tp @s -146.5 -47.5 62.5 0 0
execute if score potions2 Text matches 630 run gamemode adventure @s
execute if score potions2 Text matches 630 run tag @s remove potions2
execute if score potions2 Text matches 630 run tag @s add potion_end
execute if score potions2 Text matches 630 run kill @e[tag=potions_entity]
execute if score potions2 Text matches 630 run scoreboard players reset potions2 Text