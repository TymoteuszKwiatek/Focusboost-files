scoreboard players add lacrimosa Text 1
execute if score lacrimosa Text matches 4020.. run playsound minecraft:lacrimosa master @s ~ ~ ~ 5 1
execute if score lacrimosa Text matches 4020.. run scoreboard players reset lacrimosa Text