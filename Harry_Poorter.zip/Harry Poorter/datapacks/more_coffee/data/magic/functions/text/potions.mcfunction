scoreboard players add potions Text 1

execute if score potions Text matches 1 run item replace entity @s armor.head with minecraft:carved_pumpkin{Enchantments:[{id:"minecraft:binding_curse",lvl:1s}]}
execute if score potions Text matches 1 run gamemode spectator @s
execute if score potions Text matches 1 run function magic:text/misc/potions_cam
execute if score potions Text matches 10 run spectate @e[tag=potions_cam,limit=1] @s

# look at doors
execute if score potions Text matches 40 as @e[tag=potions_cam] at @s run tp @s ~ ~ ~ -101.4 1.4
execute if score potions Text matches 40 run playsound minecraft:dzwonek master @s -147.19 -47.24 66.33 10000 0.7

# students init
execute if score potions Text matches 39 run summon minecraft:item_display -139 -47 60 {NoGravity:1,Invulnerable:1,item:{id:"minecraft:beef",Count:1b},Tags:["potions_student1","potions_entity"],Rotation:[180f,0f]}
execute if score potions Text matches 39 run summon minecraft:item_display -139 -47 61 {NoGravity:1,Invulnerable:1,item:{id:"minecraft:beef",Count:1b},Tags:["potions_student2","potions_entity"],Rotation:[180f,0f]}
execute if score potions Text matches 39 run summon minecraft:item_display -139 -47 60 {NoGravity:1,Invulnerable:1,item:{id:"minecraft:beef",Count:1b},Tags:["potions_student3","potions_entity"],Rotation:[180f,0f]}
execute if score potions Text matches 39 run summon minecraft:item_display -139 -47 61 {NoGravity:1,Invulnerable:1,item:{id:"minecraft:beef",Count:1b},Tags:["potions_student4","potions_entity"],Rotation:[180f,0f]}
execute if score potions Text matches 39 run summon minecraft:item_display -139 -47 60 {NoGravity:1,Invulnerable:1,item:{id:"minecraft:beef",Count:1b},Tags:["potions_student5","potions_entity"],Rotation:[180f,0f]}
execute if score potions Text matches 39 run summon minecraft:item_display -139 -47 61 {NoGravity:1,Invulnerable:1,item:{id:"minecraft:beef",Count:1b},Tags:["potions_student6","potions_entity"],Rotation:[180f,0f]}
execute if score potions Text matches 39 run summon minecraft:item_display -139 -47 60 {NoGravity:1,Invulnerable:1,item:{id:"minecraft:beef",Count:1b},Tags:["potions_student7","potions_entity"],Rotation:[180f,0f]}
execute if score potions Text matches 39 run summon minecraft:item_display -139 -47 61 {NoGravity:1,Invulnerable:1,item:{id:"minecraft:beef",Count:1b},Tags:["potions_student8","potions_entity"],Rotation:[180f,0f]}
execute if score potions Text matches 39 run summon minecraft:item_display -139 -47 60 {NoGravity:1,Invulnerable:1,item:{id:"minecraft:beef",Count:1b},Tags:["potions_student9","potions_entity"],Rotation:[180f,0f]}

# students in
execute if score potions Text matches 40..160 as @e[tag=potions_student1] at @s run tp @s ^ ^ ^0.1 facing entity @e[tag=potions_student1_pos,limit=1]
execute if score potions Text matches 40..160 as @e[tag=potions_student2] at @s run tp @s ^ ^ ^0.1 facing entity @e[tag=potions_student2_pos,limit=1]
execute if score potions Text matches 40..160 as @e[tag=potions_student3] at @s run tp @s ^ ^ ^0.1 facing entity @e[tag=potions_student3_pos,limit=1]
execute if score potions Text matches 40..160 as @e[tag=potions_student4] at @s run tp @s ^ ^ ^0.1 facing entity @e[tag=potions_student4_pos,limit=1]
execute if score potions Text matches 40..160 as @e[tag=potions_student5] at @s run tp @s ^ ^ ^0.1 facing entity @e[tag=potions_student5_pos,limit=1]
execute if score potions Text matches 40..160 as @e[tag=potions_student6] at @s run tp @s ^ ^ ^0.1 facing entity @e[tag=potions_student6_pos,limit=1]
execute if score potions Text matches 40..160 as @e[tag=potions_student7] at @s run tp @s ^ ^ ^0.1 facing entity @e[tag=potions_student7_pos,limit=1]
execute if score potions Text matches 40..160 as @e[tag=potions_student8] at @s run tp @s ^ ^ ^0.1 facing entity @e[tag=potions_student8_pos,limit=1]
execute if score potions Text matches 40..160 as @e[tag=potions_student9] at @s run tp @s ^ ^ ^0.1 facing entity @e[tag=potions_student9_pos,limit=1]

# teacher in
execute if score potions Text matches 161 as @e[tag=potions_student4] run tp @s -152 -48 59
execute if score potions Text matches 161 as @e[tag=potions_student5] run tp @s -154 -48 59
execute if score potions Text matches 161 as @e[tag=potions_student6] run tp @s -153 -48 62
execute if score potions Text matches 161 as @e[tag=potions_student7] run tp @s -151 -48 62
execute if score potions Text matches 161 as @e[tag=potions_student8] run tp @s -152 -48 65
execute if score potions Text matches 161 as @e[tag=potions_student9] run tp @s -154 -48 65

execute if score potions Text matches 161 positioned -148 -47 70 summon minecraft:item_display run data merge entity @s {item:{id:"minecraft:bread",Count:1b},Tags:["potions_teacher","potions_entity"],transformation:{scale:[3.5,1.5,1.5]}}
execute if score potions Text matches 161 as @e[tag=potions_cam] at @s run tp @s ~ ~ ~ 0 0
execute if score potions Text matches 161 as @e[tag=potions_entity,type=item_display,tag=!potions_cam,tag=!potions_teacher,tag=!potions_CauldronModel] at @s align xyz positioned ~0.5 ~ ~0.5 run tp @s ~ ~ ~ 180 0

# teacher talk
execute if score potions Text matches 170 run tellraw @s [{"text":"<Nauczyciel>","color":"gold"},{"color":"gray","bold":"false","text":" Siema ziomki! To nasza pierwsza lekcja potek w "},{"text":"[","bold":"true","color":"white"},{"text":"Biedoszkoła","bold":"false","color":"gold"},{"text":"]","bold":"true","color":"white"},{"color":"gray","bold":"false","text":" i będę waszym nauczycielem chemii"}]
execute if score potions Text matches 170 run playsound minecraft:talk1 master @s ~ ~ ~ 1 1
execute if score potions Text matches 300 run tellraw @s [{"text":"<Nauczyciel>","color":"gold"},{"color":"gray","bold":"false","text":" Nazywajcie mnie Bogden Nieduży"}]
execute if score potions Text matches 300 run playsound minecraft:talk2 master @s ~ ~ ~ 1 1
execute if score potions Text matches 400 run tellraw @s [{"text":"<Bogden Nieduży>","color":"gold"},{"color":"gray","bold":"false","text":" Napoje, które tu powstaną przydadzą się wam wszystkim w dalszym życiu lub gdzie indziej"}]
execute if score potions Text matches 400 run playsound minecraft:talk3 master @s ~ ~ ~ 1 1

# friend talk
execute if score potions Text matches 520 as @e[tag=potions_cam] at @s run tp @s ~ ~ ~ -91.8 4.0
execute if score potions Text matches 520 as @e[tag=potions_student3] at @s run tp @s ~ ~ ~ -91.8 4.0
execute if score potions Text matches 520 run tellraw @s [{"text":"<Bogden Nieduży>","color":"gold"},{"color":"gray","bold":"false","text":" Lorem ipsum dolor sit amet, consectetur adipiscing elit"}]

execute if score potions Text matches 520 run tellraw @s [{"text":"<Marian Dajgrosz>","color":"green"},{"color":"gray","bold":"false","text":" ej, wiesz może o czym on gada?"}]
execute if score potions Text matches 520 run playsound minecraft:talk1 master @s ~ ~ ~ 1 2
execute if score potions Text matches 620 run tellraw @s [{"text":"<Marian Dajgrosz>","color":"green"},{"color":"gray","bold":"false","text":" btw, lubie potki, są w uj dobre, zawsze kiedy je pije, budzę się w szpitalu, MAJĄ TAM JEDZENIE! ;O..."}]
execute if score potions Text matches 620 run playsound minecraft:talk2 master @s ~ ~ ~ 1 2
execute if score potions Text matches 720 run tellraw @s [{"text":"<Marian Dajgrosz>","color":"green"},{"color":"gray","bold":"false","text":" Ugh, dobra, ta szkoła śmierdzi!"}]
execute if score potions Text matches 720 run playsound minecraft:talk3 master @s ~ ~ ~ 1 2

# angry teacher
execute if score potions Text matches 780 as @e[tag=potions_teacher] at @s run playsound minecraft:meme1 master @s ~ ~ ~ 1 1
execute if score potions Text matches 780 as @e[tag=potions_teacher] at @s run tp @s -147.7 -47 63.0 60 4.0

execute if score potions Text matches 780 as @e[tag=potions_student3] at @s run tp @s ~ ~ ~ 180 0
execute if score potions Text matches 780 as @e[tag=potions_cam] at @s run tp @s ~ ~ ~ 60 50
execute if score potions Text matches 780..800 as @e[tag=potions_cam] at @s run tp @s ~ ~ ~ 60 ~-3.5
execute if score potions Text matches 780 run tellraw @s [{"text":"<Bogden Nieduży>","color":"gold"},{"color":"gray","bold":"false","text":" Przepraszam, co powiedziałeś?!"}]
execute if score potions Text matches 780 run playsound minecraft:meme1 master @s ~ ~ ~ 1 1

execute if score potions Text matches 810 run tellraw @s [{"text":"<Bogden Nieduży>","color":"gold"},{"color":"gray","bold":"false","text":" Czy muszę ciebie stąd wyrzucić?"}]
execute if score potions Text matches 810 run playsound minecraft:meme1 master @s ~ ~ ~ 1 1

execute if score potions Text matches 890 run tellraw @s [{"text":"<Bogden Nieduży>","color":"gold"},{"color":"gray","bold":"false","text":" Tym razem ci odpuszczę, ale teraz się skup i stwórz CAŁKOWICIE-POWAŻNA-POTĘŻNA-BŁYSKOTLIWA-\n-MIKSTURA-WSPANIAŁEGO-NICZEGO"}]
execute if score potions Text matches 890 run playsound minecraft:meme1 master @s ~ ~ ~ 1 1

execute if score potions Text matches 1000 run tellraw @s [{"text":"<Bogden Nieduży>","color":"gold"},{"color":"gray","bold":"false","text":" Wszystkie składniki znajdziecie w MOJEJJ sali, tylko ostrzegam, są niebezpieczne!"}]
execute if score potions Text matches 1000 run playsound minecraft:talk1 master @s ~ ~ ~ 1 1

# fade
execute if score potions Text matches 1110 run title @s times 10 20 10
execute if score potions Text matches 1110 run title @s title {"text":"\uE000"}

# teacher back gameplay phase
execute if score potions Text matches 1120 as @e[tag=potions_teacher] at @s run tp @s -148 -47 70 0 0
execute if score potions Text matches 1120 run item replace entity @s armor.head with minecraft:air 1
execute if score potions Text matches 1120 run gamemode adventure @s
execute if score potions Text matches 1120 run tag @s add potions_gameplay
execute if score potions Text matches 1120 run tag @s remove potions
execute if score potions Text matches 1120 run scoreboard players reset potions Text


